import torch
import math

def generate_rich_dashboard(title, header_rows, logs, progress_table):
    from rich.panel import Panel
    from rich.table import Table
    from rich.console import Group

    header = Table.grid(padding=(0, 2))
    for _ in header_rows[0]:
        header.add_column(justify="left")
    for row in header_rows:
        header.add_row(*row)

    # Show last 10 log lines so users can track progress across more epochs
    log_text = "\n".join(logs[-10:]) if logs else "Starting sequence..."

    return Group(
        Panel(header,    title=f"[bold white]{title}[/bold white]",      border_style="blue"),
        Panel(log_text,  title="[bold white]Historical Logs[/bold white]", border_style="green"),
        Panel(progress_table, border_style="magenta", padding=(0, 1))
    )

def get_system_ram_str():
    """Returns a formatted string of active system RAM usage cross-platform."""
    try:
        import psutil
        ram = psutil.virtual_memory()
        return f"{ram.used / (1024**3):.1f} GB / {ram.total / (1024**3):.1f} GB"
    except ImportError:
        pass
        
    import os
    if os.name == 'nt':
        try:
            import ctypes
            class MemoryStatusEx(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]
            stat = MemoryStatusEx()
            stat.dwLength = ctypes.sizeof(MemoryStatusEx)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            total = stat.ullTotalPhys / (1024**3)
            used = (stat.ullTotalPhys - stat.ullAvailPhys) / (1024**3)
            return f"{used:.1f} GB / {total:.1f} GB"
        except:
            pass
    elif os.name == 'posix':
        try:
            with open('/proc/meminfo', 'r') as f:
                meminfo = f.read()
            total = 0
            available = 0
            for line in meminfo.splitlines():
                if 'MemTotal' in line:
                    total = int(line.split()[1]) * 1024 # extract bytes
                if 'MemAvailable' in line:
                    available = int(line.split()[1]) * 1024
            if total > 0:
                # Fallback if MemAvailable unsupported
                used = total - available if available > 0 else 0 
                return f"{used / (1024**3):.1f} GB / {total / (1024**3):.1f} GB"
        except:
            pass
            
    return "Unknown"

def safe_load(path, map_location=None):
    """Load a checkpoint, preferring weights_only=True for security.
    Falls back to weights_only=False with a warning if the checkpoint
    was saved by an older PyTorch version or contains non-standard objects.
    """
    try:
        return torch.load(path, map_location=map_location, weights_only=True)
    except Exception:
        from rich.console import Console
        Console().print(f"[bold yellow][!] Warning: Safe load failed for {path}. Falling back to full unpickle. Only load checkpoints you trust.[/bold yellow]")
        return torch.load(path, map_location=map_location, weights_only=False)

def load_and_verify_state_dict(model, state_dict, source_path):
    import os, shutil
    try:
        model.load_state_dict(state_dict, strict=True)
        return True
    except Exception as e:
        from rich.console import Console
        c = Console()
        c.print(f"\n[bold red][!] ERROR: Shape mismatch detected in {source_path}.[/bold red]")
        c.print(f"         [dim]{e}[/dim]")
        c.print(f"         [bold yellow]Archiving incompatible checkpoint to prevent data loss...[/bold yellow]")
        archive_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "archive")
        os.makedirs(archive_dir, exist_ok=True)
        new_path = os.path.join(archive_dir, os.path.basename(source_path))
        try:
            shutil.move(source_path, new_path)
            c.print(f"         Moved to [dim]{new_path}[/dim].")
        except Exception as move_e:
            c.print(f"         [bold red]Failed to move file to {new_path}: {move_e}[/bold red]")
        return False

