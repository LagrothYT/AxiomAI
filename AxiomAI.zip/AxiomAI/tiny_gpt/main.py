import sys
import os
import subprocess
import json
import time
import glob
import math
from utils import safe_load
import config

# ── Helpers ─────────────────────────────────────────────────────────────────

def format_size(size_bytes):
    if size_bytes == 0:
        return "0 B"
    names = ("B", "KB", "MB", "GB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    return f"{round(size_bytes / math.pow(1024, i), 2)} {names[i]}"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# ── Mtime-aware cache ────────────────────────────────────────────────────────
# Expensive stats (token counts, model metrics) are computed once and cached.
# They only recompute when the underlying files actually change on disk.
# File-existence checks (status indicators) are always live and bypass the cache.

_cache = {}

def _mt(path):
    try:
        return os.path.getmtime(path)
    except OSError:
        return None

def _cached(key, paths, compute_fn):
    current_mtimes = {p: _mt(p) for p in paths}
    if key in _cache and _cache[key]['mtimes'] == current_mtimes:
        return _cache[key]['value']
    value = compute_fn()
    _cache[key] = {'mtimes': current_mtimes, 'value': value}
    return value

# ── Status (instant — file existence only) ───────────────────────────────────

def get_status():
    tok_path   = os.path.join(config.tokenizer_dir, "tokenizer.json")
    pre_d_path = os.path.join(config.processed_data_dir, "pretrain.npy")
    sft_d_path = os.path.join(config.processed_data_dir, "sft_ids.npy")
    pre_m_path = config.best_model_path.replace("best.pt", "pretrain_best.pt")
    sft_m_path = config.best_model_path.replace("best.pt", "sft_best.pt")

    def mark(path):
        return "[bold green][X][/bold green]" if os.path.exists(path) else "[dim][ ][/dim]"

    lines = []
    lines.append("  [bold]Text Pipeline[/bold]")
    lines.append(f"    Tokenizer:      {mark(tok_path)}    "
                 f"Pretrain Data: {mark(pre_d_path)}    "
                 f"SFT Data: {mark(sft_d_path)}")
    lines.append(f"    Pretrain Model: {mark(pre_m_path)}    "
                 f"SFT Model:     {mark(sft_m_path)}")

    try:
        from image_generation.config import ImageModelConfig
        img_cfg = ImageModelConfig.load()
        base    = os.path.dirname(os.path.abspath(__file__))
        vae_p   = os.path.join(base, img_cfg.output_dir_model, "vae_best.pt")
        diff_p  = os.path.join(base, img_cfg.output_dir_model, "diffusion_best.pt")
        lines.append("  [bold]Image Pipeline[/bold]")
        lines.append(f"    VAE (The Eyes): {mark(vae_p)}    "
                     f"Diffusion (The Brain): {mark(diff_p)}")
    except Exception:
        lines.append("  [bold]Image Pipeline[/bold]")
        lines.append("    [dim][!] Could not load image config[/dim]")

    return "\n".join(lines)

# ── Data specs (cached by mtime — token counting only on file change) ─────────

def get_data_specs():
    pretrain_files = glob.glob(os.path.join(config.pretrain_data_dir, "*.jsonl"))
    sft_files      = glob.glob(os.path.join(config.sft_data_dir,      "*.jsonl"))
    tok_path       = os.path.join(config.tokenizer_dir, "tokenizer.json")
    tracked        = sorted(pretrain_files + sft_files + [tok_path])

    def _compute():
        tokenizer = None
        if os.path.exists(tok_path):
            try:
                from tokenizer.bpe import BPETokenizer
                tokenizer = BPETokenizer.load(tok_path)
            except Exception:
                pass

        def _split_stats(files, label):
            if not files:
                return f"  Text [{label}]: [dim][!] No .jsonl files found[/dim]"
            raw_size     = sum(os.path.getsize(f) for f in files)
            conv_count   = 0
            total_tokens = 0
            for fpath in files:
                with open(fpath, "r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            item = json.loads(line)
                            conv_count += 1
                            if tokenizer:
                                text = " ".join(
                                    f"{c.get('from','')}: {c.get('value','')}"
                                    for c in item.get("conversations", [])
                                )
                                total_tokens += len(tokenizer.encode(text))
                        except Exception:
                            continue
            tok_str = f" | Tokens: {total_tokens:,}" if tokenizer else ""
            return (f"  Text [{label}]: {len(files)} file(s) "
                    f"({format_size(raw_size)}) | Items: {conv_count:,}{tok_str}")

        lines = []
        lines.append(_split_stats(pretrain_files, "Pretrain"))
        lines.append(_split_stats(sft_files,      "SFT"))

        try:
            from image_generation.config import ImageModelConfig
            img_cfg = ImageModelConfig.load()
            img_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   img_cfg.data_dir)
            if not os.path.exists(img_dir):
                lines.append(f"  Image: [dim][!] Directory '{img_cfg.data_dir}' not found[/dim]")
            else:
                img_count = sum(
                    1 for _, _, fs in os.walk(img_dir)
                    for fn in fs if fn.lower().endswith(('.png', '.jpg', '.jpeg'))
                )
                lines.append(f"  Image: {img_count:,} image(s) in '{img_cfg.data_dir}/'")
        except Exception as e:
            lines.append(f"  Image: [dim][!] {e}[/dim]")

        return "\n".join(lines)

    return _cached("data", tracked, _compute)

# ── Model specs (cached by mtime — model loading only on checkpoint change) ───

def get_model_specs():
    sft_path = config.best_model_path.replace("best.pt", "sft_best.pt")
    pre_path = config.best_model_path.replace("best.pt", "pretrain_best.pt")
    try:
        from image_generation.config import ImageModelConfig
        img_cfg  = ImageModelConfig.load()
        base     = os.path.dirname(os.path.abspath(__file__))
        vae_path = os.path.join(base, img_cfg.output_dir_model, "vae_best.pt")
        dif_path = os.path.join(base, img_cfg.output_dir_model, "diffusion_best.pt")
    except Exception:
        img_cfg  = None
        vae_path = ""
        dif_path = ""

    tracked = [p for p in [sft_path, pre_path, vae_path, dif_path] if p]

    def _compute():
        lines = []

        # Text model
        loaded = (sft_path if os.path.exists(sft_path) else
                  pre_path if os.path.exists(pre_path) else None)
        if not loaded:
            lines.append("  Text Engine:  [dim][!] No model trained yet[/dim]")
        else:
            try:
                file_size = format_size(os.path.getsize(loaded))
                ckpt      = safe_load(loaded, map_location='cpu')
                if isinstance(ckpt, dict) and "epoch" in ckpt:
                    ep       = ckpt.get("epoch", 0) + 1
                    val_loss = ckpt.get("best_val_loss", 0.0)
                else:
                    ep, val_loss = "?", 0.0
                ppl          = round(math.exp(val_loss), 2) if val_loss > 0 else "?"
                val_loss_str = round(val_loss, 4)           if val_loss > 0 else "?"
                try:
                    from model.transformer import TinyGPT
                    shell     = TinyGPT(vocab_size=config.vocab_size,
                                        d_model=config.d_model,  n_layers=config.n_layers,
                                        n_heads=config.n_heads,  d_ff=config.d_ff,
                                        max_seq_len=config.max_seq_len)
                    param_str = f"{sum(p.numel() for p in shell.parameters())/1e6:.2f}M Params | "
                except Exception:
                    param_str = ""
                lines.append(f"  Text Engine:  [bold]{os.path.basename(loaded)}[/bold] ({file_size})")
                lines.append(f"                Epoch {ep} | Val Loss: {val_loss_str} | PPL: {ppl}")
                lines.append(f"                {param_str}{config.vocab_size:,} Vocab | {config.max_seq_len} Context")
            except Exception as e:
                lines.append(f"  Text Engine:  [dim][!] Error reading metrics: {e}[/dim]")

        lines.append("")

        # Image models
        if img_cfg is None:
            lines.append("  Image Engine: [dim][!] Could not load image config[/dim]")
        else:
            try:
                vae_sz  = format_size(os.path.getsize(vae_path)) if os.path.exists(vae_path) else "Missing"
                diff_sz = format_size(os.path.getsize(dif_path)) if os.path.exists(dif_path) else "Missing"
                w, h    = img_cfg.image_width, img_cfg.image_height
                df      = img_cfg.vae_downsample_factor
                try:
                    from image_generation.model.vae import VAE
                    from image_generation.model.diffusion import LatentDiffusion
                    vp  = sum(p.numel() for p in VAE(3, img_cfg.vae_channels, [64,128,256]).parameters()) / 1e6
                    dp  = sum(p.numel() for p in LatentDiffusion(img_cfg.diffusion_channels, img_cfg.text_embedding_dim).parameters()) / 1e6
                    arch = f"VAE ({vp:.2f}M) | UNet ({dp:.2f}M) Params"
                except Exception:
                    arch = ""
                lines.append(f"  Image Engine: vae_best.pt ({vae_sz}) | diffusion_best.pt ({diff_sz})")
                if arch:
                    lines.append(f"                {arch}")
                lines.append(f"                {w}x{h} ({w*h:,} px) | Latent {w//df}x{h//df} ({df}x downsample)")
            except Exception as e:
                lines.append(f"  Image Engine: [dim][!] {e}[/dim]")

        return "\n".join(lines)

    return _cached("model", tracked, _compute)

# ── Command runner ───────────────────────────────────────────────────────────

def run_command(command):
    from rich.console import Console
    console = Console()
    try:
        full_cmd = [sys.executable] + command
        console.print(f"\n[bold cyan]Running:[/bold cyan] [dim]{' '.join(full_cmd)}[/dim]\n")
        subprocess.run(full_cmd, check=True)
        return True
    except subprocess.CalledProcessError:
        console.print("\n[bold red][!] Command exited with an error.[/bold red]")
        return False
    except Exception as e:
        console.print(f"\n[bold red][!] Error:[/bold red] {e}")
        return False

# ── Input helpers ────────────────────────────────────────────────────────────

def get_validated_input(prompt, default, min_val, max_val, as_int=False):
    from rich.console import Console
    console = Console()
    while True:
        try:
            raw = input(f"  {prompt} [{default}]: ").strip()
            if not raw:
                return default
            val = float(raw)
            if min_val <= val <= max_val:
                return int(val) if as_int else val
            console.print(f"  [red]Must be between {min_val} and {max_val}.[/red]")
        except ValueError:
            console.print(f"  [red]Invalid value.[/red]")

# ── Main menu ────────────────────────────────────────────────────────────────

def interactive_menu():
    from rich.console import Console
    from rich.panel import Panel
    console = Console()

    try:
        from image_generation.config import ImageModelConfig
        img_cfg      = ImageModelConfig.load()
        vae_req_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                     img_cfg.output_dir_model, "vae_best.pt")
    except Exception:
        vae_req_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                     "model", "vae_best.pt")

    prereqs = {
        "3": [(os.path.join(config.tokenizer_dir, "tokenizer.json"),   "Tokenizer"),
              (os.path.join(config.processed_data_dir, "pretrain.npy"), "Pretrain Data")],
        "5": [(os.path.join(config.tokenizer_dir, "tokenizer.json"),   "Tokenizer"),
              (os.path.join(config.processed_data_dir, "sft_ids.npy"), "SFT Data")],
        "7": [(vae_req_path, "VAE Model")],
        "8": [(os.path.join(config.tokenizer_dir, "tokenizer.json"),   "Tokenizer")],
    }

    last_error = None

    while True:
        clear_screen()

        def req_tag(key):
            missing = [n for p, n in prereqs.get(key, []) if not os.path.exists(p)]
            return f"  [dim red](needs: {', '.join(missing)})[/dim red]" if missing else ""

        body  = f"[bold cyan]System Status[/bold cyan]\n{get_status()}\n\n"
        body += f"[bold cyan]Dataset Info[/bold cyan]\n{get_data_specs()}\n\n"
        body += f"[bold cyan]Model Info[/bold cyan]\n{get_model_specs()}\n\n"

        if last_error:
            body = f"[bold red][!] Last operation failed (option {last_error})[/bold red]\n\n" + body

        body += "[bold magenta]Text Pipeline[/bold magenta]\n"
        body += f"  [bold white][1][/bold white] Train Tokenizer\n"
        body += f"  [bold white][2][/bold white] Preprocess Data [dim](Pretrain)[/dim]\n"
        body += f"  [bold white][3][/bold white] Pretrain Model{req_tag('3')}\n"
        body += f"  [bold white][4][/bold white] Preprocess Data [dim](SFT)[/dim]\n"
        body += f"  [bold white][5][/bold white] SFT Fine-tune{req_tag('5')}\n\n"
        body += "[bold magenta]Image Pipeline[/bold magenta]\n"
        body += f"  [bold white][6][/bold white] Train Image VAE [dim](The Eyes)[/dim]\n"
        body += f"  [bold white][7][/bold white] Train Diffusion [dim](The Brain)[/dim]{req_tag('7')}\n\n"
        body += "[bold magenta]Application[/bold magenta]\n"
        body += f"  [bold white][8][/bold white] Launch Chat{req_tag('8')}\n"
        body += f"  [bold white][9][/bold white] Exit\n"

        console.print()
        console.print(Panel(body,
                            title="[bold cyan]TinyGPT Studio & Control Center[/bold cyan]",
                            border_style="cyan",
                            padding=(1, 2)))

        choice = input("\n  > ").strip()

        if choice in prereqs:
            missing = [n for p, n in prereqs[choice] if not os.path.exists(p)]
            if choice == "8":
                pre_m = config.best_model_path.replace("best.pt", "pretrain_best.pt")
                sft_m = config.best_model_path.replace("best.pt", "sft_best.pt")
                if not os.path.exists(pre_m) and not os.path.exists(sft_m):
                    missing.append("Model Checkpoint (run option 3 first)")
            if missing:
                console.print(f"\n  [bold red][!] Missing:[/bold red] {', '.join(missing)}")
                time.sleep(2)
                continue

        success = True
        if   choice == "1": success = run_command(["tokenizer/train_tokenizer.py"])
        elif choice == "2": success = run_command(["data/prepare_data.py", "--mode", "pretrain"])
        elif choice == "3": success = run_command(["train.py", "--mode", "pretrain"])
        elif choice == "4": success = run_command(["data/prepare_data.py", "--mode", "sft"])
        elif choice == "5": success = run_command(["train.py", "--mode", "sft"])
        elif choice == "6": success = run_command(["-m", "image_generation.train", "--mode", "vae"])
        elif choice == "7": success = run_command(["-m", "image_generation.train", "--mode", "diffusion"])
        elif choice == "8":
            console.print("\n  [bold cyan]── Chat Settings ──────────────────[/bold cyan]")
            temp       = get_validated_input("Temperature",    config.temperature,    0.0, 2.0)
            top_p      = get_validated_input("Top-p",          config.top_p,          0.0, 1.0)
            max_tokens = get_validated_input("Max New Tokens", config.max_new_tokens, 1,
                                             config.max_seq_len, as_int=True)
            success = run_command(["chat.py",
                                   "--temperature",    str(temp),
                                   "--top_p",          str(top_p),
                                   "--max_new_tokens", str(max_tokens)])
        elif choice == "9":
            console.print("\n  [bold yellow]Goodbye.[/bold yellow]\n")
            break
        else:
            console.print("\n  [red]Invalid choice.[/red]")
            time.sleep(1)
            continue

        last_error = None if success else choice

        if choice in ["1","2","3","4","5","6","7","8"]:
            input("\n  Press Enter to return to menu...")


def main():
    try:
        interactive_menu()
    except KeyboardInterrupt:
        print("\nExiting...")
        sys.exit(0)

if __name__ == "__main__":
    main()
