import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, n_heads, dropout=0.1):
        super().__init__()
        assert d_model % n_heads == 0
        
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        
        self.w_q = nn.Linear(d_model, d_model)
        self.w_k = nn.Linear(d_model, d_model)
        self.w_v = nn.Linear(d_model, d_model)
        self.w_o = nn.Linear(d_model, d_model)
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x, mask=None, past_kv=None, pos=None):
        batch_size, seq_len, _ = x.size()
        
        q = self.w_q(x).view(batch_size, seq_len, self.n_heads, self.d_k)
        k = self.w_k(x).view(batch_size, seq_len, self.n_heads, self.d_k)
        v = self.w_v(x).view(batch_size, seq_len, self.n_heads, self.d_k).transpose(1, 2)
        
        if pos is None:
            past_len = past_kv[0].size(-2) if past_kv is not None else 0
            pos = torch.arange(past_len, past_len + seq_len, device=x.device)
            
        freqs = 1.0 / (10000.0 ** (torch.arange(0, self.d_k, 2, device=x.device).float() / self.d_k))
        freqs = torch.outer(pos, freqs)
        freqs_cis = torch.polar(torch.ones_like(freqs), freqs).unsqueeze(0).unsqueeze(2)
        
        q_c = torch.view_as_complex(q.float().reshape(*q.shape[:-1], -1, 2))
        k_c = torch.view_as_complex(k.float().reshape(*k.shape[:-1], -1, 2))
        q = torch.view_as_real(q_c * freqs_cis).flatten(3).type_as(x)
        k = torch.view_as_real(k_c * freqs_cis).flatten(3).type_as(x)
        
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        
        if past_kv is not None:
            past_k, past_v = past_kv
            k = torch.cat([past_k, k], dim=-2)
            v = torch.cat([past_v, v], dim=-2)
            
        present_kv = (k, v)
        
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_k)
        
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
            
        attn = F.softmax(scores, dim=-1)
        attn = self.dropout(attn)
        
        output = torch.matmul(attn, v)
        output = output.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        
        return self.w_o(output), present_kv

class FeedForward(nn.Module):
    def __init__(self, d_model, d_ff, dropout=0.1):
        super().__init__()
        self.linear1 = nn.Linear(d_model, d_ff)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(d_ff, d_model)
        
    def forward(self, x):
        return self.linear2(self.dropout(F.gelu(self.linear1(x))))

class TransformerBlock(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = MultiHeadAttention(d_model, n_heads, dropout)
        self.ln2 = nn.LayerNorm(d_model)
        self.ff = FeedForward(d_model, d_ff, dropout)
        
    def forward(self, x, mask=None, past_kv=None, pos=None):
        attn_out, present_kv = self.attn(self.ln1(x), mask, past_kv, pos)
        x = x + attn_out
        x = x + self.ff(self.ln2(x))
        return x, present_kv

class TinyGPT(nn.Module):
    def __init__(self, vocab_size, d_model, n_layers, n_heads, d_ff, max_seq_len, dropout=0.1):
        super().__init__()
        self.token_emb = nn.Embedding(vocab_size, d_model)
        self.dropout = nn.Dropout(dropout)
        
        self.layers = nn.ModuleList([
            TransformerBlock(d_model, n_heads, d_ff, dropout)
            for _ in range(n_layers)
        ])
        
        self.ln_f = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)
        
        self.token_emb.weight = self.head.weight
        self.max_seq_len = max_seq_len

    def forward(self, idx, targets=None, mask=None, past_key_values=None, use_cache=False):
        batch_size, seq_len = idx.size()
        
        past_len = past_key_values[0][0].size(-2) if past_key_values is not None else 0
        total_len = past_len + seq_len
        
        pos = torch.arange(past_len, total_len, dtype=torch.long, device=idx.device)
        x = self.token_emb(idx)
        x = self.dropout(x)
        
        if mask is None:
            if past_key_values is not None:
                mask = torch.ones((1, 1, seq_len, total_len), device=idx.device)
            else:
                mask = torch.tril(torch.ones((seq_len, seq_len), device=idx.device)).view(1, 1, seq_len, seq_len)
        else:
            mask = mask.to(idx.device)
            
        present_key_values = []
        for i, layer in enumerate(self.layers):
            past_kv = past_key_values[i] if past_key_values is not None else None
            x, present_kv = layer(x, mask, past_kv, pos=pos)
            present_key_values.append(present_kv)
            
        x = self.ln_f(x)
        logits = self.head(x)
        
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=0)
            
        if use_cache:
            return logits, loss, present_key_values
        return logits, loss
        
    @staticmethod
    def _sample_next_token(logits, temperature=1.0, top_p=None):
        if temperature > 0.0:
            logits = logits / temperature
            if top_p is not None:
                sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cumulative_probs > top_p
                sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                sorted_indices_to_remove[..., 0] = 0
                indices_to_remove = torch.zeros_like(logits, dtype=torch.bool).scatter_(1, sorted_indices, sorted_indices_to_remove)
                logits[indices_to_remove] = -float('Inf')
                
            probs = F.softmax(logits, dim=-1)
            idx_next = torch.multinomial(probs, num_samples=1)
            token_prob = probs.gather(1, idx_next).item()
        else:
            idx_next = torch.argmax(logits, dim=-1, keepdim=True)
            token_prob = 1.0
            
        return idx_next, token_prob

    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0, top_p=None, eos_id=None):
        import time
        probs_out = []
        start_time = time.time()
        past_kv = None
        
        for _ in range(max_new_tokens):
            idx_cond = idx if past_kv is None else idx_next
            
            seq_len = idx.size(1)
            if seq_len >= self.max_seq_len:
                past_kv = None
                idx_cond = idx[:, -self.max_seq_len:]
                
            logits, _, past_kv = self(idx_cond, past_key_values=past_kv, use_cache=True)
            logits = logits[:, -1, :]
            
            idx_next, token_prob = self._sample_next_token(logits, temperature, top_p)
                
            probs_out.append(token_prob)
            idx = torch.cat((idx, idx_next), dim=1)
            
            if eos_id is not None and idx_next.item() == eos_id:
                break
                
        end_time = time.time()
        gen_time = end_time - start_time
        return idx, probs_out, gen_time

    @torch.no_grad()
    def generate_stream(self, idx, max_new_tokens, temperature=1.0, top_p=None, eos_id=None):
        import time
        start_time = time.time()
        past_kv = None
        
        for _ in range(max_new_tokens):
            idx_cond = idx if past_kv is None else idx_next
            
            seq_len = idx.size(1)
            if seq_len >= self.max_seq_len:
                past_kv = None
                idx_cond = idx[:, -self.max_seq_len:]
            
            logits, _, past_kv = self(idx_cond, past_key_values=past_kv, use_cache=True)
            logits = logits[:, -1, :]
            
            idx_next, token_prob = self._sample_next_token(logits, temperature, top_p)
            
            idx = torch.cat((idx, idx_next), dim=1)
            
            yield idx_next.item(), token_prob
            
            if eos_id is not None and idx_next.item() == eos_id:
                break
