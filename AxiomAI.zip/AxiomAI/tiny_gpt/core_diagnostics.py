def evaluate_training_health(train_history, val_history):
    """
    Evaluates training health using slope analysis, gap tracking, and oscillation
    detection across a rolling window of epochs. Returns a graduated severity
    message — never a binary pass/fail — so the user always knows exactly where
    they are on the spectrum between learning and broken.

    Severity ladder (low → high):
      🔎  Monitoring  — not enough data yet
      ✅  Good        — things are working
      🏁  Converging  — loss stabilising, consider stopping or LR decay
      🟡  Watch       — early warning, not critical yet
      🟠  Warning     — action may be needed soon
      🔴  Critical    — intervene now
      💀  Fatal       — fundamental problem
    """
    n = len(val_history)

    # ── Not enough data ─────────────────────────────────────────────────────
    if n < 2:
        return "  --> 🔎 [dim]Gathering baseline data — need at least 2 epochs.[/dim]"

    current_val   = val_history[-1]
    current_train = train_history[-1]
    gap           = current_val - current_train   # positive = val worse than train

    # ── 1. FATAL: loss is near random-chance baseline ────────────────────────
    # For a vocab of ~5 000 tokens, random-guess cross-entropy ≈ ln(5000) ≈ 8.5.
    # Staying above 7.0 after 3+ epochs means the model has learned nothing.
    if n >= 3 and current_val > 7.0:
        return (
            "  --> 💀 [bold red]FATAL:[/bold red] Loss is near random-chance "
            f"({current_val:.4f}). Check for tokenizer/vocab ID mismatch or corrupt data."
        )

    # ── 2. Compute rolling slopes ────────────────────────────────────────────
    # Use a 5-epoch window where available; fall back to whatever we have.
    window      = min(n, 5)
    val_slope   = (val_history[-1]   - val_history[-window])  / window
    train_slope = (train_history[-1] - train_history[-window]) / window

    # ── 3. Oscillation detection ─────────────────────────────────────────────
    # Count sign changes in the val loss trend over the last 5 epochs.
    # 2+ reversals = the loss is bouncing, usually caused by LR too high.
    if n >= 4:
        sign_changes = sum(
            1 for i in range(1, min(n, 5) - 1)
            if (val_history[-i] - val_history[-(i+1)]) *
               (val_history[-(i+1)] - val_history[-(i+2)]) < 0
        )
        if sign_changes >= 2:
            return (
                f"  --> 🟠 [yellow]OSCILLATING:[/yellow] Val loss is bouncing "
                f"({current_val:.4f}). Learning rate is likely too high — try halving it."
            )

    # ── 4. Overfitting spectrum ──────────────────────────────────────────────
    # We check both the slope of val loss AND the train/val gap magnitude.
    # This gives a 3-level graduated warning instead of a binary flag.
    if n >= 3:
        # Level 3 — Critical overfitting: val rising fast AND gap is large
        if val_slope > 0.08 and gap > current_train * 0.5:
            return (
                f"  --> 🔴 [bold red]OVERFITTING:[/bold red] Val loss rising sharply "
                f"(slope {val_slope:+.4f}) with a large train/val gap ({gap:.4f}). "
                "Trigger early stopping or increase dropout."
            )
        # Level 2 — Developing overfitting: val clearly trending up
        if val_slope > 0.04:
            return (
                f"  --> 🟠 [yellow]OVERFITTING WARNING:[/yellow] Val loss is trending "
                f"upward (slope {val_slope:+.4f}). "
                "Early stopping may trigger in the next few epochs."
            )
        # Level 1 — Early signal: gap is widening but val not rising fast yet
        if gap > current_train * 0.35 and val_slope > 0.0:
            return (
                f"  --> 🟡 [yellow]OVERFITTING RISK:[/yellow] Train/val gap is growing "
                f"({gap:.4f}). Watch closely — generalisation may be starting to degrade."
            )

    # ── 5. Underfitting / stagnation spectrum ────────────────────────────────
    # Measure absolute change over 4 epochs; near-zero movement at high loss = stuck.
    if n >= 4:
        val_delta   = abs(val_history[-1]   - val_history[-4])
        train_delta = abs(train_history[-1] - train_history[-4])

        # Critical stagnation: barely moved AND loss is still high
        if val_delta < 0.02 and train_delta < 0.02 and current_val > 2.5:
            return (
                f"  --> 🔴 [bold red]STAGNATION:[/bold red] Loss has barely moved in "
                f"4 epochs (Δval={val_delta:.4f}) at a high loss of {current_val:.4f}. "
                "Try a larger learning rate, more data, or a bigger model."
            )
        # Early deceleration: slowing down but not fully stuck
        if val_delta < 0.06 and train_delta < 0.06 and current_val > 2.0:
            return (
                f"  --> 🟡 [yellow]DECELERATING:[/yellow] Progress is slowing "
                f"(Δval={val_delta:.4f} over 4 epochs). "
                "Consider a learning rate warm-up or check data diversity."
            )

    # ── 6. Convergence ───────────────────────────────────────────────────────
    # Loss is low AND the slope is nearly flat — this is healthy convergence.
    if current_val < 2.0 and abs(val_slope) < 0.015:
        return (
            f"  --> 🏁 [bold green]CONVERGING:[/bold green] Loss stabilising at "
            f"{current_val:.4f} (slope {val_slope:+.4f}). "
            "Consider stopping here or decaying the learning rate further."
        )

    # ── 7. Healthy learning ──────────────────────────────────────────────────
    if val_slope < -0.05 and train_slope < -0.05:
        return (
            f"  --> ✅ [green]LEARNING WELL:[/green] Both losses declining steadily "
            f"(val slope {val_slope:+.4f}). "
            f"Val: {current_val:.4f} | Train: {current_train:.4f} | Gap: {gap:.4f}"
        )
    if val_slope < 0 and train_slope < 0:
        return (
            f"  --> ✅ [green]PROGRESSING:[/green] Losses improving. "
            f"Val: {current_val:.4f} | Train: {current_train:.4f} | Gap: {gap:.4f}"
        )

    # ── 8. Fallback: something is moving but unclear direction ───────────────
    return (
        f"  --> 🔎 [dim]Monitoring — Val: {current_val:.4f} | "
        f"Train: {current_train:.4f} | Slope: {val_slope:+.4f}[/dim]"
    )
