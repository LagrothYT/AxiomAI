import os
import sys
import argparse
import math
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import LambdaLR
from torch.utils.data import DataLoader, TensorDataset, random_split
from rich.live import Live
from rich.progress import Progress, BarColumn, TextColumn
from rich.console import Console
import copy
import numpy as np

import config
from model.transformer import TinyGPT
from tokenizer.bpe import BPETokenizer
from utils import safe_load
from core_diagnostics import evaluate_training_health
import time

console = Console()

def train():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", type=str, choices=["pretrain", "sft"], required=True)
    parser.add_argument("--resume", type=str, default="", help="Path to checkpoint to resume from")
    args = parser.parse_args()
    
    config.ensure_dirs()
    
    # Global deterministic seed
    torch.manual_seed(config.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    console.print(f"[bold cyan]Using device:[/bold cyan] {device}")
    
    tokenizer_path = os.path.join(config.tokenizer_dir, "tokenizer.json")
    if not os.path.exists(tokenizer_path):
        console.print(f"[bold red]Error: Tokenizer not found at {tokenizer_path}. Run train_tokenizer.py first.[/bold red]")
        sys.exit(1)
    # Tokenizer is loaded to ensure we match the trained vocab size
    tokenizer = BPETokenizer.load(tokenizer_path)
    current_vocab_size = len(tokenizer.vocab)
    
    model = TinyGPT(
        vocab_size=current_vocab_size, # Use actual size from trained tokenizer
        d_model=config.d_model,
        n_layers=config.n_layers,
        n_heads=config.n_heads,
        d_ff=config.d_ff,
        max_seq_len=config.max_seq_len,
        dropout=config.dropout
    ).to(device)
    


    class PretrainMemmapDataset(torch.utils.data.Dataset):
        def __init__(self, data_path):
            self.data = np.load(data_path, mmap_mode='r')
        def __len__(self): return len(self.data)
        def __getitem__(self, idx):
            item = self.data[idx]
            return torch.tensor(item[:-1], dtype=torch.long), torch.tensor(item[1:], dtype=torch.long)

    class SFTMemmapDataset(torch.utils.data.Dataset):
        def __init__(self, ids_path, mask_path):
            self.ids = np.load(ids_path, mmap_mode='r')
            self.masks = np.load(mask_path, mmap_mode='r')
        def __len__(self): return len(self.ids)
        def __getitem__(self, idx):
            t_id = torch.tensor(self.ids[idx], dtype=torch.long)
            t_mask = torch.tensor(self.masks[idx], dtype=torch.float32)
            return t_id[:-1], t_id[1:], t_mask[1:]

    # Load processed data via memmap to prevent RAM exhaustion
    if args.mode == "pretrain":
        data_path = os.path.join(config.processed_data_dir, "pretrain.npy")
        if not os.path.exists(data_path):
            console.print(f"[bold red]Error: Processed data not found at {data_path}. Run prepare_data.py first.[/bold red]")
            sys.exit(1)
        dataset = PretrainMemmapDataset(data_path)
    else:
        ids_path = os.path.join(config.processed_data_dir, "sft_ids.npy")
        mask_path = os.path.join(config.processed_data_dir, "sft_masks.npy")
        if not os.path.exists(ids_path) or not os.path.exists(mask_path):
            console.print(f"[bold red]Error: Processed SFT data not found. Run prepare_data.py first.[/bold red]")
            sys.exit(1)
        dataset = SFTMemmapDataset(ids_path, mask_path)
        
    if len(dataset) < 2:
        console.print("[bold yellow]Warning: Dataset too small for validation split. Using all data for training.[/bold yellow]")
        train_ds = dataset
        val_ds = dataset
    else:
        train_size = int((1.0 - config.val_split) * len(dataset))
        val_size = len(dataset) - train_size
        # Ensure at least one validation sample if we have data to spare
        if val_size == 0:
            train_size -= 1
            val_size = 1
        torch.manual_seed(config.seed)
        train_ds, val_ds = random_split(dataset, [train_size, val_size])
    
    train_loader = DataLoader(train_ds, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=config.batch_size)
    
    param_dict = {n: p for n, p in model.named_parameters()}
    decay_params = [p for n, p in param_dict.items() if p.dim() >= 2]
    no_decay_params = [p for n, p in param_dict.items() if p.dim() < 2]
    
    param_groups = [
        {"params": decay_params, "weight_decay": config.weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0}
    ]
    
    optimizer = optim.AdamW(param_groups, lr=config.lr)
    
    # Global Step-based LR Scheduler
    total_steps = config.epochs * math.ceil(len(train_loader) / config.grad_accum_steps)
    warmup_steps = config.warmup_steps
    
    def lr_lambda(current_step):
        if current_step < warmup_steps:
            return float(current_step + 1) / float(warmup_steps)
        # Cosine decay from 1.0 down to min_lr ratio
        progress = float(current_step - warmup_steps) / float(max(1, total_steps - warmup_steps))
        return config.min_lr_ratio + (1.0 - config.min_lr_ratio) * 0.5 * (1.0 + math.cos(math.pi * progress))
    
    scheduler = LambdaLR(optimizer, lr_lambda)
    best_val_loss = float('inf')
    best_model_state = None
    epochs_no_improve = 0
    start_epoch = 0
    
    train_history = []
    val_history = []
    
    # Determine logic for automatic resume / checkpoint selection
    if not args.resume:
        if args.mode == "sft":
            sft_best = config.best_model_path.replace("best.pt", "sft_best.pt")
            pretrain_best = config.best_model_path.replace("best.pt", "pretrain_best.pt")
            
            if os.path.exists(sft_best):
                args.resume = sft_best
            elif os.path.exists(pretrain_best):
                args.resume = pretrain_best
                console.print(f"[bold cyan]Found pretraining results. Building SFT on top of {os.path.basename(pretrain_best)}...[/bold cyan]")
        else:
            # For pretrain mode, only auto-resume if pretrain_best exists
            pre_best = config.best_model_path.replace("best.pt", "pretrain_best.pt")
            if os.path.exists(pre_best):
                args.resume = pre_best

    if args.resume:
        if os.path.exists(args.resume):
            console.print(f"Resuming training from {os.path.basename(args.resume)}...")
            checkpoint = safe_load(args.resume, map_location=device)
            state_to_load = checkpoint["model"] if "model" in checkpoint else checkpoint
            from utils import load_and_verify_state_dict
            
            if load_and_verify_state_dict(model, state_to_load, args.resume):
                if "model" in checkpoint:
                    if "optimizer" in checkpoint:
                        optimizer.load_state_dict(checkpoint["optimizer"])
                    if "scheduler" in checkpoint:
                        scheduler.load_state_dict(checkpoint["scheduler"])
                    start_epoch = checkpoint.get("epoch", 0) + 1
                    best_val_loss = checkpoint.get("best_val_loss", float('inf'))
                    
                    # If transitioning modes, reset best_val_loss so the new mode tracks its own progress
                    if args.mode == "sft" and "pretrain" in os.path.basename(args.resume):
                        best_val_loss = float('inf')
                        console.print("[bold cyan]Resetting Best Loss baseline for SFT mode specialization...[/bold cyan]")
                        
                    console.print(f"[bold green]Resumed at epoch {start_epoch} with val_loss {best_val_loss:.4f}[/bold green]")
                else:
                    console.print("[bold yellow]Loaded bare weights. Starting from epoch 0.[/bold yellow]")
            else:
                console.print("[bold red]Starting training from scratch due to incompatible checkpoint.[/bold red]")
                args.resume = ""
        else:
            console.print(f"[bold red]Error: Resume checkpoint {args.resume} not found.[/bold red]")
            sys.exit(1)
            
    ppl_label = "SFT-PPL" if args.mode == "sft" else "PPL"
    save_path = config.best_model_path.replace("best.pt", f"{args.mode}_best.pt")
    
    params_count = sum(p.numel() for p in model.parameters()) / 1_000_000
    mode_str = args.mode.upper()
    historical_logs = []
    
    from utils import get_system_ram_str, generate_rich_dashboard
    progress = Progress(
        TextColumn("[bold blue]Epoch {task.fields[epoch]}/{task.fields[total_epochs]}"),
        BarColumn(complete_style="cyan", finished_style="green"),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("• {task.fields[metrics]}")
    )
    task_id = progress.add_task("training", total=len(train_loader), epoch=start_epoch+1, total_epochs=config.epochs, metrics="Initializing...")

    def get_current_vram():
        if torch.cuda.is_available():
            try: return f"{torch.cuda.memory_reserved(0) / (1024**3):.1f} GB / {torch.cuda.get_device_properties(0).total_memory / (1024**3):.1f} GB"
            except: pass
        return "CPU"
        
    def render_ui(current_epoch, current_metrics):
        val_loss_str = f"{best_val_loss:.4f}" if best_val_loss != float('inf') else "N/A"
        try: ppl_str = f"{math.exp(best_val_loss):.2f}" if best_val_loss != float('inf') else "N/A"
        except: ppl_str = "N/A"
        rows = [
            (f"[bold cyan]Mode:[/bold cyan] {mode_str}", f"[bold cyan]VRAM:[/bold cyan] {get_current_vram()}", f"[bold cyan]RAM:[/bold cyan] {get_system_ram_str()}"),
            (f"[bold cyan]Architecture:[/bold cyan] {params_count:.2f}M Params", f"[bold cyan]Best Loss:[/bold cyan] {val_loss_str}", f"[bold cyan]PPL:[/bold cyan] {ppl_str}")
        ]
        progress.update(task_id, epoch=current_epoch+1, total_epochs=config.epochs, metrics=current_metrics)
        return generate_rich_dashboard("TinyGPT Training Studio", rows, historical_logs, progress)

    os.system('cls' if os.name == 'nt' else 'clear')
    live = Live(render_ui(start_epoch, "Initializing..."), refresh_per_second=4)
    live.start()
    
    try:
        for epoch in range(start_epoch, config.epochs):
            model.train()
            train_loss = 0
            optimizer.zero_grad()
            _last_ui = time.time()
            
            progress.reset(task_id, total=len(train_loader))
            
            for i, batch in enumerate(train_loader):
                if args.mode == "pretrain":
                    x_b, y_b = [t.to(device) for t in batch]
                    logits, loss = model(x_b, y_b)
                else:
                    x_b, y_b, m_b = [t.to(device) for t in batch]
                    logits, _ = model(x_b)
                    loss = torch.nn.functional.cross_entropy(
                        logits.view(-1, logits.size(-1)), 
                        y_b.view(-1), 
                        reduction='none'
                    )
                    loss = (loss * m_b.view(-1)).sum() / (m_b.sum() + 1e-9)
                
                loss = loss / config.grad_accum_steps
                loss.backward()
                
                if (i + 1) % config.grad_accum_steps == 0 or (i + 1) == len(train_loader):
                    torch.nn.utils.clip_grad_norm_(model.parameters(), config.grad_clip)
                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad()
                    
                train_loss += loss.item() * config.grad_accum_steps
                
                l_val = loss.item() * config.grad_accum_steps
                try: p_val = math.exp(min(l_val, 20))
                except: p_val = 999.0
                m_str = f"Loss: {l_val:.4f} | PPL: {p_val:.2f} | LR: {optimizer.param_groups[0]['lr']:.2e}"
                progress.update(task_id, advance=1)
                _now = time.time()
                if _now - _last_ui >= 0.25:
                    live.update(render_ui(epoch, m_str))
                    _last_ui = _now
                
            avg_train_loss = train_loss / len(train_loader)
            
            model.eval()
            total_val_loss = 0
            with torch.no_grad():
                live.update(render_ui(epoch, "Validating..."))
                for batch in val_loader:
                    if args.mode == "pretrain":
                        x_b, y_b = [t.to(device) for t in batch]
                        _, loss = model(x_b, y_b)
                    else:
                        x_b, y_b, m_b = [t.to(device) for t in batch]
                        logits, _ = model(x_b)
                        loss = torch.nn.functional.cross_entropy(
                            logits.view(-1, logits.size(-1)), 
                            y_b.view(-1), 
                            reduction='none'
                        )
                        loss = (loss * m_b.view(-1)).sum() / (m_b.sum() + 1e-9)
                    total_val_loss += loss.item()
                    
            avg_val_loss = total_val_loss / max(1, len(val_loader))
            
            train_ppl = torch.exp(torch.tensor(avg_train_loss)).item()
            val_ppl = torch.exp(torch.tensor(avg_val_loss)).item()
            
            is_best = avg_val_loss < best_val_loss
            best_marker = " [BEST]" if is_best else ""
            
            # History append for mathematical evaluation
            train_history.append(avg_train_loss)
            val_history.append(avg_val_loss)

            # Execute "AI Teacher" algorithm
            status = evaluate_training_health(train_history, val_history)
            
            log_str = f"[bold green]✓ Epoch {epoch+1}: Loss[/bold green] [T: {avg_train_loss:.4f}, V: {avg_val_loss:.4f}] | {ppl_label} [T: {train_ppl:.2f}, V: {val_ppl:.2f}] | LR: {optimizer.param_groups[0]['lr']:.2e}{best_marker}"
            historical_logs.append(log_str + f"\n    [dim]{status}[/dim]")
            live.update(render_ui(epoch, "Epoch Complete\n"))
            
            if is_best:
                best_val_loss = avg_val_loss
                best_model_state = copy.deepcopy(model.state_dict())
                torch.save({
                    "model": best_model_state,
                    "optimizer": optimizer.state_dict(),
                    "scheduler": scheduler.state_dict(),
                    "epoch": epoch,
                    "best_val_loss": best_val_loss
                }, save_path) 
                
                historical_logs[-1] = historical_logs[-1] + f"\n    [bold yellow]↳ New best model saved ([dim]{save_path}[/dim])[/bold yellow]"
                epochs_no_improve = 0
            else:
                epochs_no_improve += 1
                
            # Early stopping check
            if config.early_stopping_enabled and epochs_no_improve >= config.early_stopping_patience:
                historical_logs.append(f"[bold red]Early stopping triggered after {epoch+1} epochs.[/bold red]")
                live.update(render_ui(epoch, "Halted"))
                break
                    
    except KeyboardInterrupt:
        historical_logs.append("[bold red][!] Training paused by user.[/bold red]")
        live.update(render_ui(epoch, "Paused"))
        interrupted_path = save_path.replace(".pt", "_interrupted.pt")
        torch.save({
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "epoch": epoch if 'epoch' in locals() else start_epoch,
            "best_val_loss": best_val_loss
        }, interrupted_path)
        historical_logs.append(f"    [dim]Interrupt state saved to {interrupted_path}[/dim]")

    live.stop()
    # Final cleanup after training loop
    if best_model_state is not None:
        model.load_state_dict(best_model_state)
        console.print(f"\n[bold green]Training complete.[/bold green] Best model loaded with Val Loss: {best_val_loss:.4f}\n")
    else:
        # Fallback if no validation happened or no improvement (e.g., very short training)
        # In this case, the last model state is saved if no better one was found.
        torch.save({
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "epoch": epoch if 'epoch' in locals() else 0,
            "best_val_loss": best_val_loss
        }, save_path)
        print(f"\nTraining complete. No improvement found, last model state saved to {save_path}.")


if __name__ == "__main__":
    train()
