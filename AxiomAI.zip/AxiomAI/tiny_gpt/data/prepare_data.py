import os
import json
import glob
import sys
import argparse
import torch

# Add parent directory to path to import config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from tokenizer.bpe import BPETokenizer
from rich.console import Console

console = Console()

def load_tokenizer():
    tokenizer_path = os.path.join(config.tokenizer_dir, "tokenizer.json")
    if not os.path.exists(tokenizer_path):
        console.print(f"[bold red]Error: Tokenizer not found at {tokenizer_path}. Run train_tokenizer.py first.[/bold red]")
        sys.exit(1)
    return BPETokenizer.load(tokenizer_path)

def process_pretrain(tokenizer):
    console.print("[bold cyan]Processing data for pretraining...[/bold cyan]")
    jsonl_files = glob.glob(os.path.join(config.pretrain_data_dir, "*.jsonl"))
    txt_files   = glob.glob(os.path.join(config.pretrain_data_dir, "*.txt"))

    if not jsonl_files and not txt_files:
        console.print("[bold red]Error: No .jsonl or .txt files found in data/pretrain/[/bold red]")
        return

    from tqdm import tqdm
    total_size = (sum(os.path.getsize(f) for f in jsonl_files) +
                  sum(os.path.getsize(f) for f in txt_files))
    pbar = tqdm(total=total_size, unit='B', unit_scale=True, desc="Prep: Pretrain")

    bos_id = tokenizer.vocab.get("<BOS>")
    eos_id = tokenizer.vocab.get(config.eos_token, tokenizer.vocab.get("<EOS>", 3))
    pad_id = tokenizer.vocab.get("<PAD>", 0)

    def _wrap_and_extend(text, dest):
        """Encode text, wrap with BOS/EOS, append to dest."""
        text = text.strip()
        if not text:
            return
        tokens = tokenizer.encode(text)
        if bos_id is not None:
            tokens = [bos_id] + tokens
        tokens = tokens + [eos_id]
        dest.extend(tokens)

    all_tokens = []

    # ShareGPT JSONL
    for file_path in jsonl_files:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                pbar.update(len(line.encode("utf-8")))
                try:
                    data = json.loads(line)
                    text = " ".join(
                        turn.get("value", "")
                        for turn in data.get("conversations", [])
                    )
                    _wrap_and_extend(text, all_tokens)
                except json.JSONDecodeError:
                    continue

    # Plain text — each non-empty line is treated as one document
    for file_path in txt_files:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                pbar.update(len(line.encode("utf-8")))
                _wrap_and_extend(line, all_tokens)

    pbar.close()

    if not all_tokens:
        console.print("[bold red]Error: No tokens produced from pretrain data.[/bold red]")
        return

    # Chunk into max_seq_len + 1 (input and target share the same array, shifted by 1)
    chunk_size = config.max_seq_len

    rem = (len(all_tokens) - 1) % chunk_size
    if rem > 0:
        all_tokens.extend([pad_id] * (chunk_size - rem))

    samples = [
        all_tokens[i:i + chunk_size + 1]
        for i in range(0, len(all_tokens) - chunk_size + 1, chunk_size)
    ]

    if not samples:
        console.print("[bold red]Error: Not enough data to form even one training sample.[/bold red]")
        return

    import numpy as np
    # int32 supports vocab sizes up to ~2 billion — uint16 was capped at 65 535
    samples_np = np.array(samples, dtype=np.int32)
    output_path = os.path.join(config.processed_data_dir, "pretrain.npy")
    np.save(output_path, samples_np)
    console.print(f"[bold green]Saved {len(samples):,} pretraining samples to {output_path}[/bold green]")

def process_sft(tokenizer):
    console.print("[bold cyan]Processing data for SFT...[/bold cyan]")
    jsonl_files = glob.glob(os.path.join(config.sft_data_dir, "*.jsonl"))

    if not jsonl_files:
        console.print("[bold red]Error: No .jsonl files found in data/sft/[/bold red]")
        return

    from tqdm import tqdm
    total_size = sum(os.path.getsize(f) for f in jsonl_files)
    pbar = tqdm(total=total_size, unit='B', unit_scale=True, desc="Prep: SFT")
    
    all_samples = []  # List of (input_ids, loss_mask)
    
    human_prefix  = f"{config.human_role}: "
    gpt_prefix    = f"{config.gpt_role}: "
    system_prefix = f"{config.system_role}: "
    eos_id = tokenizer.vocab.get(config.eos_token, 3)
    bos_id = tokenizer.vocab.get("<BOS>")
    pad_id = tokenizer.vocab.get("<PAD>", 0)
    
    for file_path in jsonl_files:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                pbar.update(len(line.encode('utf-8')))
                try:
                    data = json.loads(line)
                    curr_ids  = []
                    curr_mask = []

                    if bos_id is not None:
                        curr_ids.append(bos_id)
                        curr_mask.append(0)
                    
                    for turn in data.get("conversations", []):
                        role    = turn.get("from")
                        content = turn.get("value", "")
                        
                        if role == "human":
                            turn_tokens = tokenizer.encode(human_prefix) + tokenizer.encode(content)
                            curr_ids.extend(turn_tokens)
                            curr_mask.extend([0] * len(turn_tokens))
                        elif role == "system":
                            turn_tokens = tokenizer.encode(system_prefix) + tokenizer.encode(content)
                            curr_ids.extend(turn_tokens)
                            curr_mask.extend([0] * len(turn_tokens))
                        elif role == "gpt":
                            prefix_tokens  = tokenizer.encode(gpt_prefix)
                            content_tokens = tokenizer.encode(content) + [eos_id]
                            curr_ids.extend(prefix_tokens)
                            curr_mask.extend([0] * len(prefix_tokens))
                            curr_ids.extend(content_tokens)
                            curr_mask.extend([1] * len(content_tokens))
                            
                    target_len = config.max_seq_len + 1
                    if len(curr_ids) > target_len:
                        curr_ids  = curr_ids[:target_len]
                        curr_mask = curr_mask[:target_len]
                    elif len(curr_ids) < target_len:
                        pad_len = target_len - len(curr_ids)
                        curr_ids.extend([pad_id] * pad_len)
                        curr_mask.extend([0] * pad_len)
                        
                    all_samples.append((curr_ids, curr_mask))
                except json.JSONDecodeError:
                    continue
    pbar.close()
                    
    if not all_samples:
        console.print("[bold red]Error: No samples found for SFT.[/bold red]")
        return
        
    import numpy as np
    # int32 supports vocab sizes up to ~2 billion — uint16 was capped at 65 535
    ids_np  = np.array([s[0] for s in all_samples], dtype=np.int32)
    mask_np = np.array([s[1] for s in all_samples], dtype=np.float32)
    
    ids_path  = os.path.join(config.processed_data_dir, "sft_ids.npy")
    mask_path = os.path.join(config.processed_data_dir, "sft_masks.npy")
    
    np.save(ids_path,  ids_np)
    np.save(mask_path, mask_np)
    console.print(f"[bold green]Saved {len(all_samples):,} SFT samples to .npy format[/bold green]")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", type=str, choices=["pretrain", "sft"], required=True)
    args = parser.parse_args()
    
    config.ensure_dirs()
    tokenizer = load_tokenizer()
    
    if args.mode == "pretrain":
        process_pretrain(tokenizer)
    else:
        process_sft(tokenizer)

if __name__ == "__main__":
    main()
