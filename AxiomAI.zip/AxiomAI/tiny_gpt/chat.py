import os
import sys
import argparse
import torch
import json
import math
import time

import config
from model.transformer import TinyGPT
from tokenizer.bpe import BPETokenizer
from image_generation.bridge import ModelBridge
from utils import safe_load

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

console = Console()

def print_header(model_info=None, args=None):
    os.system('cls' if os.name == 'nt' else 'clear')
    from rich.rule import Rule
    from rich.text import Text

    cmd_line  = "[bold white]Commands:[/bold white] /quit  /clear  /help  /imagine"
    arch_line = "[bold white]Architecture:[/bold white] Base GPT & Factor-4 Latent Diffusion"

    if model_info:
        info_line = f"[bold white]Model:[/bold white] {model_info}"
    else:
        info_line = ""

    settings_line = ""
    if args:
        settings_line = (f"[bold white]Settings:[/bold white] "
                         f"temp={args.temperature}  top_p={args.top_p}  "
                         f"max_tokens={args.max_new_tokens}  "
                         f"ctx={config.max_seq_len}")

    body = "\n".join(line for line in [cmd_line, arch_line, info_line, settings_line] if line)

    panel = Panel(
        body,
        title="[bold cyan]TinyGPT Interactive Chat[/bold cyan]",
        border_style="cyan",
        padding=(1, 2)
    )
    console.print()
    console.print(panel)
    console.print()

def chat():
    parser = argparse.ArgumentParser()
    parser.add_argument("--temperature", type=float, default=config.temperature)
    parser.add_argument("--top_p", type=float, default=config.top_p)
    parser.add_argument("--max_new_tokens", type=int, default=config.max_new_tokens)
    parser.add_argument("--json_output", action="store_true")
    args = parser.parse_args()
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    tokenizer_path = os.path.join(config.tokenizer_dir, "tokenizer.json")
    if not os.path.exists(tokenizer_path):
        console.print(f"[bold red]Error: Tokenizer not found at {tokenizer_path}[/bold red]")
        return
    tokenizer = BPETokenizer.load(tokenizer_path)
    
    if args.max_new_tokens >= config.max_seq_len:
        console.print(f" [bold red][SYSTEM] Warning:[/bold red] max_new_tokens ({args.max_new_tokens}) is >= max_seq_len ({config.max_seq_len}).")
        console.print(" [dim]Automatically reducing max_new_tokens to half of context window for stability.[/dim]")
        args.max_new_tokens = config.max_seq_len // 2
    
    model = TinyGPT(
        vocab_size=len(tokenizer.vocab),
        d_model=config.d_model,
        n_layers=config.n_layers,
        n_heads=config.n_heads,
        d_ff=config.d_ff,
        max_seq_len=config.max_seq_len,
        dropout=0.0 # No dropout during inference
    ).to(device)
    
    sft_path = config.best_model_path.replace("best.pt", "sft_best.pt")
    pretrain_path = config.best_model_path.replace("best.pt", "pretrain_best.pt")
    model_path = sft_path if os.path.exists(sft_path) else pretrain_path
    
    if not os.path.exists(model_path):
        console.print("[bold red]Error: Model checkpoint not found.[/bold red]")
        return
        
    checkpoint = safe_load(model_path, map_location=device)
    from utils import load_and_verify_state_dict
    state_to_load = checkpoint["model"] if "model" in checkpoint else checkpoint
    if not load_and_verify_state_dict(model, state_to_load, model_path):
        console.print("[bold yellow]Please rerun pretraining or SFT to generate a compatible checkpoint.[/bold yellow]")
        return
    model.eval()
    
    bridge = ModelBridge()
    history = []

    # Build a one-line model summary for the header
    try:
        param_count = sum(p.numel() for p in model.parameters()) / 1e6
        model_label = os.path.basename(model_path)
        model_info  = (f"{model_label} | {param_count:.2f}M params | "
                       f"{len(tokenizer.vocab):,} vocab | {config.max_seq_len} ctx")
    except Exception:
        model_info = None

    if not args.json_output:
        print_header(model_info=model_info, args=args)
    
    while True:
        try:
            user_input = input(f" {config.user_prefix} > ").strip()
            if not user_input:
                continue
                
            if user_input.lower() == "/quit":
                if not args.json_output:
                    console.print("\n[bold cyan]  Goodbye.[/bold cyan]\n")
                break
            if user_input.lower() == "/clear":
                history = []
                if not args.json_output:
                    print_header(model_info=model_info, args=args)
                    console.print("[bold yellow]  ── Chat history cleared ──[/bold yellow]\n")
                continue
                
            if user_input.lower() == "/help":
                if not args.json_output:
                    console.print(Panel(
                        "[bold white]/quit[/bold white]     Exit the chat\n"
                        "[bold white]/clear[/bold white]    Clear history and redraw screen\n"
                        "[bold white]/imagine[/bold white]  Generate an image  [dim](e.g. /imagine a sunset)[/dim]\n"
                        "[bold white]/help[/bold white]     Show this message\n\n"
                        f"[bold white]Temperature:[/bold white]  {args.temperature}\n"
                        f"[bold white]Top-p:[/bold white]        {args.top_p}\n"
                        f"[bold white]Max tokens:[/bold white]   {args.max_new_tokens}\n"
                        f"[bold white]Context:[/bold white]      {config.max_seq_len} tokens",
                        title="[bold cyan]Help[/bold cyan]",
                        border_style="cyan",
                        padding=(1, 2)
                    ))
                continue
                
            if user_input.strip().startswith("/imagine"):
                bridge_result = bridge.process_chat_message(user_input)
                if bridge_result.get("type") == "image":
                    if not args.json_output:
                        console.print(f" [bold cyan][SYSTEM][/bold cyan] [dim]Direct User Routing: Image Pipeline initialized for:[/dim] [bold white]{bridge_result['prompt']}[/bold white]")
                    history.append({"from": "human", "value": user_input})
                    history.append({"from": "gpt", "value": "[Image Generated Successfully]"})
                else:
                    if not args.json_output:
                        console.print(f" [bold red][SYSTEM] Error:[/bold red] {bridge_result.get('content', 'Unknown bridge error')}")
                continue
                
            history.append({"from": "human", "value": user_input})
            
            trimmed = False
            truncated = False
            while True:
                prompt = ""
                if config.default_system_prompt:
                    prompt += f"{config.system_role}: {config.default_system_prompt}\n"
                    
                for turn in history:
                    role_prefix = f"{config.human_role}: " if turn["from"] == "human" else f"{config.gpt_role}: "
                    prompt += f"{role_prefix}{turn['value']} "
                prompt += f"{config.gpt_role}: "
                
                encoded_prompt = tokenizer.encode(prompt)

                # Prepend BOS so the model's prompt format matches training data.
                bos_id = tokenizer.vocab.get("<BOS>")
                if bos_id is not None and (not encoded_prompt or encoded_prompt[0] != bos_id):
                    encoded_prompt = [bos_id] + encoded_prompt
                
                if len(encoded_prompt) + args.max_new_tokens <= config.max_seq_len:
                    break
                
                if len(history) > 1:
                    history.pop(0)
                    if history and history[0]["from"] == "gpt":
                        history.pop(0)
                    trimmed = True
                else:
                    # Final safety: if we can't trim history, truncate the current message
                    limit = max(1, config.max_seq_len - args.max_new_tokens)
                    encoded_prompt = encoded_prompt[-limit:]
                    truncated = True
                    break
            
            if not args.json_output:
                if truncated:
                    console.print(f" [bold yellow][SYSTEM][/bold yellow] [dim]Message too long — truncated to {config.max_seq_len - args.max_new_tokens} tokens.[/dim]")
                elif trimmed:
                    console.print(" [bold yellow][SYSTEM][/bold yellow] [dim]Old context trimmed to fit window.[/dim]")

            input_ids = torch.tensor([encoded_prompt], dtype=torch.long).to(device)

            eos_id = tokenizer.vocab.get(config.eos_token, 3)

            if not args.json_output:
                console.print(Rule(style="dim"))
                print(f" {config.gpt_prefix}  > ", end="", flush=True)

            stream = model.generate_stream(
                input_ids, 
                max_new_tokens=args.max_new_tokens, 
                temperature=args.temperature, 
                top_p=args.top_p,
                eos_id=eos_id
            )
            
            probs = []
            num_tokens = 0
            
            start_time = time.time()
            initial_seq_len = input_ids.size(1)
            
            printed_text = ""
            curr_sequence = []
            
            for item, val in stream:
                probs.append(val)
                num_tokens += 1
                
                if item == eos_id:
                    break
                    
                curr_sequence.append(item)
                
                
                new_text = tokenizer.decode([item], clean_up=False)
                
                if not args.json_output:
                    print(new_text, end="", flush=True)
                
                printed_text += new_text
                
            gen_time = time.time() - start_time
                
            if not args.json_output:
                print()
                
            response = tokenizer.decode(curr_sequence, clean_up=True, skip_special_tokens=True)
            
            bridge_result = bridge.process_chat_message(response)
            if bridge_result.get("type") == "image":
                if not args.json_output:
                    console.print(f" [bold cyan][SYSTEM][/bold cyan] [dim]Routing to image pipeline:[/dim] [bold white]{bridge_result['prompt']}[/bold white]")
            elif bridge_result.get("type") == "error":
                if not args.json_output:
                    console.print(f" [bold red][SYSTEM] Generator Error:[/bold red] {bridge_result.get('content')}")

            context_used = initial_seq_len + num_tokens
            context_left = max(0, config.max_seq_len - context_used)
            ctx_pct      = int(100 * context_used / config.max_seq_len)
            perplexity   = math.exp(-sum(math.log(max(p, 1e-10)) for p in probs) / len(probs)) if probs else 1.0
            tok_per_sec  = num_tokens / gen_time if gen_time > 0 else 0

            if args.json_output:
                print(json.dumps({
                    "response": response,
                    "tokens": num_tokens,
                    "perplexity": f"{perplexity:.2f}",
                    "tok_s": f"{tok_per_sec:.1f}",
                    "context_left": context_left
                }))
            else:
                console.print(
                    f" [dim]└─ {num_tokens} tok · {tok_per_sec:.1f} tok/s · "
                    f"PPL {perplexity:.2f} · ctx {ctx_pct}% used ({context_left} left)[/dim]"
                )
                console.print()
                
            history.append({"from": "gpt", "value": response})
            
        except EOFError:
            break
        except KeyboardInterrupt:
            console.print("\n\n[bold cyan]  Session ended.[/bold cyan]\n")
            break

if __name__ == "__main__":
    chat()
