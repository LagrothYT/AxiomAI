import os
import json
import glob
import sys

# Add parent directory to path to import config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from tokenizer.bpe import BPETokenizer
from rich.console import Console

console = Console()

def load_sharegpt_texts():
    texts = []
    jsonl_files = glob.glob(os.path.join(config.pretrain_data_dir, "*.jsonl")) + glob.glob(os.path.join(config.sft_data_dir, "*.jsonl"))
    
    if not jsonl_files:
        return texts
        
    for file_path in jsonl_files:
        console.print(f"Loading [dim]{file_path}[/dim]...")
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    data = json.loads(line)
                    for turn in data.get("conversations", []):
                        texts.append(turn.get("value", ""))
                except json.JSONDecodeError:
                    continue
    return texts


def load_plain_texts():
    """Load raw .txt files from pretrain and sft data directories.
    Each non-empty line is treated as a separate training text."""
    texts = []
    txt_files = (
        glob.glob(os.path.join(config.pretrain_data_dir, "*.txt")) +
        glob.glob(os.path.join(config.sft_data_dir, "*.txt"))
    )
    for file_path in txt_files:
        console.print(f"Loading [dim]{file_path}[/dim]...")
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    texts.append(line)
    return texts

def main():
    config.ensure_dirs()
    
    console.print("[bold cyan]Collecting texts for tokenizer training...[/bold cyan]")
    texts = load_sharegpt_texts() + load_plain_texts()
    
    if not texts:
        console.print("[bold red]Error: No text found in data/pretrain/ or data/sft/.[/bold red]")
        console.print("[yellow]Supported formats: ShareGPT .jsonl files and plain .txt files (one text per line).[/yellow]")
        sys.exit(1)
        
    tokenizer_path = os.path.join(config.tokenizer_dir, "tokenizer.json")
    if os.path.exists(tokenizer_path):
        ans = console.input(f"[bold yellow]Tokenizer already exists at {tokenizer_path}.\nRe-train and overwrite? (y/N): [/bold yellow]").strip().lower()
        if ans != 'y':
            console.print("[bold red]Aborted.[/bold red]")
            sys.exit(0)
            
    console.print(f"Collected {len(texts)} turns. Training BPE tokenizer (target vocab size: {config.vocab_size})...")
    
    tokenizer = BPETokenizer(vocab_size=config.vocab_size)
    tokenizer.train(texts)
    
    tokenizer_path = os.path.join(config.tokenizer_dir, "tokenizer.json")
    tokenizer.save(tokenizer_path)
    console.print(f"[bold green]Tokenizer saved successfully to {tokenizer_path}[/bold green]")

if __name__ == "__main__":
    main()
