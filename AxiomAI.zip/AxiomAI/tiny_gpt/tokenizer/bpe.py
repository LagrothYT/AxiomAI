import json
import os
import re
import heapq
from collections import Counter, defaultdict
from tqdm import tqdm

# GPT-2-style pre-tokenization: separates punctuation, contractions, and numbers before BPE
# GPT-2-style pre-tokenization with Unicode support.
# [^\W\d]+ matches any Unicode letter (including accented, CJK, Arabic, etc.) without digits.
# [^\s\w]+ catches punctuation and symbols.
PRE_TOK_PATTERN = re.compile(
    r"""'s|'t|'re|'ve|'m|'ll|'d"""
    r"""| ?[^\W\d]+"""
    r"""| ?[0-9]+"""
    r"""| ?[^\s\w]+"""
    r"""|\s+""",
    re.UNICODE
)

class BPETokenizer:
    def __init__(self, vocab_size=5000):
        self.vocab_size = vocab_size
        self._target_vocab_size = vocab_size  # preserves the original training target; vocab_size may drift after load()
        self.vocab = {}  # token -> id
        self.id_to_token = {}  # id -> token
        self.merges = {}  # (p1, p2) -> merged_token
        self.special_tokens = ["<PAD>", "<UNK>", "<BOS>", "<EOS>", "[HUMAN]", "[GPT]", "[SYSTEM]"]

    @staticmethod
    def _pre_tokenize(text):
        """Split text into words using GPT-2-style regex pre-tokenization with Ġ marker."""
        words = []
        for match in re.findall(PRE_TOK_PATTERN, text):
            if match.startswith(' '):
                words.append('Ġ' + match[1:])
            else:
                words.append(match)
        return words
        
    def train(self, texts):
        # Add special tokens
        for i, token in enumerate(self.special_tokens):
            self.vocab[token] = i
            self.id_to_token[i] = token
            
        word_freqs = Counter()
        for text in texts:
            for word in self._pre_tokenize(text):
                word_freqs[" ".join(list(word)) + " </w>"] += 1
        
        parts = {word: word.split() for word in word_freqs}
        stats = defaultdict(int)
        for word, freq in word_freqs.items():
            symbols = parts[word]
            for i in range(len(symbols) - 1):
                stats[symbols[i], symbols[i+1]] += freq
        
        chars = set()
        for word in word_freqs:
            for char in parts[word]:
                chars.add(char)
        
        start_idx = len(self.vocab)
        for i, char in enumerate(sorted(list(chars))):
            self.vocab[char] = i + start_idx
            self.id_to_token[i + start_idx] = char
            
        queue = []
        for pair, freq in stats.items():
            heapq.heappush(queue, (-freq, pair))
            
        # Optimization: Map pair to list of words containing it
        pair_to_words = defaultdict(set)
        for word, symbols in parts.items():
            for i in range(len(symbols) - 1):
                pair_to_words[symbols[i], symbols[i+1]].add(word)
                
        num_merges = self.vocab_size - len(self.vocab)
        loop = tqdm(range(num_merges), desc="Training BPE")
        for i in loop:
            if not queue:
                break
            
            best_pair = None
            while queue:
                neg_freq, pair = heapq.heappop(queue)
                if pair in stats and stats[pair] == -neg_freq:
                    best_pair = pair
                    break
                    
            if not best_pair or stats[best_pair] <= 0:
                break
                
            new_id = len(self.vocab)
            new_token = "".join(best_pair)
            self.vocab[new_token] = new_id
            self.id_to_token[new_id] = new_token
            self.merges[best_pair] = i
            
            # Efficiently update affected words
            affected_words = list(pair_to_words[best_pair])
            for word in affected_words:
                freq = word_freqs[word]
                symbols = parts[word]
                
                # Find all occurrences of best_pair in this word
                j = 0
                new_symbols = []
                while j < len(symbols):
                    if j < len(symbols) - 1 and (symbols[j], symbols[j+1]) == best_pair:
                        # Before merging, remove broken pairs from stats
                        if j > 0:
                            left_pair = (symbols[j-1], symbols[j])
                            stats[left_pair] -= freq
                            pair_to_words[left_pair].discard(word)
                        if j < len(symbols) - 2:
                            # Avoid double counting if the NEXT pair is also a best_pair
                            # But standard BPE merges one at a time.
                            # However, we must remove the right pair because symbols[j+1] will be gone.
                            right_pair = (symbols[j+1], symbols[j+2])
                            stats[right_pair] -= freq
                            pair_to_words[right_pair].discard(word)
                        
                        new_symbols.append(new_token)
                        j += 2
                    else:
                        new_symbols.append(symbols[j])
                        j += 1
                
                # Update stats for newly created pairs in this word
                parts[word] = new_symbols
                for k in range(len(new_symbols) - 1):
                    if new_symbols[k] == new_token or new_symbols[k+1] == new_token:
                        pair = (new_symbols[k], new_symbols[k+1])
                        stats[pair] += freq
                        pair_to_words[pair].add(word)
                        heapq.heappush(queue, (-stats[pair], pair))
            
            # Remove best_pair from stats
            del stats[best_pair]
            del pair_to_words[best_pair]
            
            if (i + 1) % 100 == 0:
                loop.set_description(f"BPE merge {i+1}/{num_merges}: {best_pair[0]} + {best_pair[1]} -> {new_token}")

    def encode(self, text, add_special_tokens=False, max_length=None, truncation=False, padding=False, pad_to_length=None):
        if not text:
            return []
            
        # 1. Isolate special tokens using unbreakable placeholders.
        # The pre-tokenization regex fragments tokens containing brackets or symbols (e.g. [HUMAN] -> [, HUMAN, ]).
        # We temporarily swap them for alphanumeric markers that fit the ' ?[a-zA-Z]+' regex group.
        placeholder_to_token = {}
        processed_text = text
        for i, special in enumerate(self.special_tokens):
            # We pad with spaces to ensure placeholders are treated as distinct words
            placeholder = f" AXIOMSPECIALTOKEN{i}X "
            placeholder_to_token[placeholder.strip()] = special
            processed_text = processed_text.replace(special, placeholder)
            
        # 2. Feed the full processed text to _pre_tokenize to preserve 'Ġ' markers
        raw_fragments = self._pre_tokenize(processed_text)
        
        # 3. Restore original special tokens from placeholders
        words = []
        for frag in raw_fragments:
            # Strip 'Ġ' if present to check against our placeholder map
            clean_frag = frag[1:] if frag.startswith('Ġ') else frag
            if clean_frag in placeholder_to_token:
                words.append(placeholder_to_token[clean_frag])
            else:
                words.append(frag)
        
        encoded_ids = []
        for word in words:
            # Skip empty strings produced by extra spaces in isolation step
            if not word: continue
            
            if word in self.special_tokens:
                encoded_ids.append(self.vocab[word])
                continue
                
            word_chars = list(word) + ["</w>"]
            if len(word_chars) < 2:
                for token in word_chars:
                    encoded_ids.append(self.vocab.get(token, self.vocab["<UNK>"]))
                continue

            nodes = []
            for i, char in enumerate(word_chars):
                nodes.append([char, i - 1, i + 1, True])
            nodes[-1][2] = -1

            queue = []
            def add_pair(l_idx, r_idx):
                pair = (nodes[l_idx][0], nodes[r_idx][0])
                if pair in self.merges:
                    heapq.heappush(queue, (self.merges[pair], l_idx, r_idx))

            for i in range(len(nodes) - 1):
                add_pair(i, i + 1)

            while queue:
                rank, l, r = heapq.heappop(queue)
                if not nodes[l][3] or not nodes[r][3] or nodes[l][2] != r:
                    continue

                new_token = nodes[l][0] + nodes[r][0]
                nodes[l][0] = new_token
                nodes[r][3] = False
                
                next_idx = nodes[r][2]
                nodes[l][2] = next_idx
                if next_idx != -1:
                    nodes[next_idx][1] = l

                prev_idx = nodes[l][1]
                if prev_idx != -1:
                    add_pair(prev_idx, l)
                if next_idx != -1:
                    add_pair(l, next_idx)

            curr = 0
            while curr != -1:
                if nodes[curr][3]:
                    token = nodes[curr][0]
                    encoded_ids.append(self.vocab.get(token, self.vocab["<UNK>"]))
                curr = nodes[curr][2]

        # Inject BOS at the start and EOS at the end if requested
        if add_special_tokens:
            bos_id = self.vocab.get("<BOS>")
            eos_id = self.vocab.get("<EOS>")
            if bos_id is not None:
                encoded_ids = [bos_id] + encoded_ids
            if eos_id is not None:
                encoded_ids = encoded_ids + [eos_id]

        # Truncate to max_length if requested
        if truncation and max_length is not None:
            encoded_ids = encoded_ids[:max_length]

        # Pad to target length if requested
        target_len = pad_to_length if pad_to_length is not None else max_length
        if padding and target_len is not None:
            pad_id = self.vocab.get("<PAD>", 0)
            if len(encoded_ids) < target_len:
                encoded_ids = encoded_ids + [pad_id] * (target_len - len(encoded_ids))

        return encoded_ids

    def decode(self, ids, clean_up=False, skip_special_tokens=False):
        if skip_special_tokens:
            special_ids = {self.vocab[t] for t in self.special_tokens if t in self.vocab}
            ids = [i for i in ids if (i if isinstance(i, int) else i.item()) not in special_ids]
        tokens = [self.id_to_token.get((i if isinstance(i, int) else i.item()), "<UNK>") for i in ids]
        text = "".join(tokens).replace("</w>", "").replace("Ġ", " ")
        # Strip the leading-space artifact that arises when the first real token
        # carries a Ġ prefix. Only strip during full-sequence decodes, not raw streaming.
        if text.startswith(" ") and (skip_special_tokens or clean_up):
            text = text[1:]
        if clean_up:
            text = " ".join(text.split())
        return text

    def save(self, path):
        # Store merges as [[p1, p2, rank], ...] triples.
        # This avoids the old "<SEP>" string delimiter which could collide with token content.
        serializable_merges = [[k[0], k[1], v] for k, v in self.merges.items()]
        data = {
            "vocab": self.vocab,
            "merges": serializable_merges,
            "vocab_size": self.vocab_size,
            "target_vocab_size": self._target_vocab_size,
            "special_tokens": self.special_tokens
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        obj = cls(vocab_size=data.get("vocab_size", 5000))
        obj._target_vocab_size = data.get("target_vocab_size", data.get("vocab_size", 5000))
        obj.special_tokens = data.get("special_tokens", ["<PAD>", "<UNK>", "<BOS>", "<EOS>", "[HUMAN]", "[GPT]", "[SYSTEM]"])
        obj.vocab = data["vocab"]
        obj.vocab_size = len(obj.vocab)
        obj.id_to_token = {int(v): k for k, v in obj.vocab.items()}
        
        obj.merges = {}
        raw_merges = data["merges"]
        if isinstance(raw_merges, list):
            # New format: list of [p1, p2, rank]
            for item in raw_merges:
                obj.merges[(item[0], item[1])] = item[2]
        else:
            # Legacy format: dict with "<SEP>" string delimiter
            for k, v in raw_merges.items():
                p1, p2 = k.split("<SEP>", 1)
                obj.merges[(p1, p2)] = v
            
        return obj

    # ------------------------------------------------------------------
    # Convenience / utility methods
    # ------------------------------------------------------------------

    def __len__(self):
        """Return the current vocabulary size."""
        return len(self.vocab)

    def tokenize(self, text):
        """Return the list of token *strings* a text splits into, without converting to IDs.
        Useful for inspecting and debugging tokenization quality."""
        ids = self.encode(text)
        return [self.id_to_token.get(i, "<UNK>") for i in ids]

    def batch_encode(self, texts, **kwargs):
        """Encode a list of texts. All kwargs are forwarded to encode()."""
        return [self.encode(t, **kwargs) for t in texts]

    def batch_decode(self, ids_list, **kwargs):
        """Decode a list of ID sequences. All kwargs are forwarded to decode()."""
        return [self.decode(ids, **kwargs) for ids in ids_list]

    def add_tokens(self, new_tokens):
        """Append new tokens to the vocabulary. Returns the count of actually added tokens.
        Already-present tokens are silently skipped."""
        added = 0
        for token in new_tokens:
            if token not in self.vocab:
                new_id = len(self.vocab)
                self.vocab[token] = new_id
                self.id_to_token[new_id] = token
                added += 1
        self.vocab_size = len(self.vocab)
        return added

    def add_special_tokens(self, new_special_tokens):
        """Add new special tokens to both the vocabulary and the special-token
        protection list used by encode(). Returns the count of actually added tokens."""
        added = self.add_tokens(new_special_tokens)
        for token in new_special_tokens:
            if token not in self.special_tokens:
                self.special_tokens.append(token)
        return added
