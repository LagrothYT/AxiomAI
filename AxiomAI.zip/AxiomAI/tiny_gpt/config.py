import os
import configparser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(BASE_DIR, "config")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.ini")

CURRENT_VERSION = "1.2"

DEFAULT_INI_TEMPLATE = f"""[System]
# Configuration file version (Do not modify this manually. Used for auto-patching when updates release)
version = {CURRENT_VERSION}

[model]
# Number of transformer layers (Depth)
# Increasing this makes the AI "smarter" and able to understand more complex logic step-by-step, but it will require significantly more RAM and train slower. (Default: 4)
n_layers = 4

# Number of attention heads
# Controls how many different "perspectives" the AI uses to look at a sentence simultaneously. Must divide evenly into d_model. (Default: 4)
n_heads = 4

# Embedding dimension (Width)
# This dictates how deeply the AI understands the "meaning" of words math-wise. Higher numbers allow it to grasp vastly subtle meanings, but take massive amounts of memory. (Default: 256)
d_model = 256

# Feed-forward network dimension
# The hidden computational space used internally during layers. Usually 4x the d_model size. (Default: 1024)
d_ff = 1024

# Maximum sequence length (Context Window)
# The absolute maximum number of words/tokens the AI can physically remember in a continuous chat text before forgetting older messages. (Default: 512)
max_seq_len = 512

# Vocabulary size of the Tokenizer
# The exact number of unique "word fragments" your Tokenizer was trained to recognize. Must exactly match the BPE token limit. (Default: 5000)
vocab_size = 5000

[training]
# Batch size per step
# How many examples the AI reads simultaneously before updating its math. High batch sizes speed up training but devour GPU VRAM instantly. (Default: 8)
batch_size = 8

# Learning rate
# How aggressive the AI alters its brain per mistake. Too high = it forgets and hallucinates; Too low = it takes forever to learn. (Default: 3e-4)
lr = 3e-4

# Number of full passes over dataset
# How many times the AI will read your absolute entire customized Data.jsonl file before stopping training. (Default: 5)
epochs = 5

# Gradient accumulation steps (Simulates larger batch size)
# Very important! Acts as a "fake" memory booster. If you have a weak GPU, keep batch_size at 1, but set this to 16. It will simulate a batch size of 16 without crashing your RAM. (Default: 4)
grad_accum_steps = 4

# Dropout probability (0.0 to 1.0)
# Helps prevent memorization (overfitting). Drops a percentage of brain connections randomly so it learns to generalize instead of copying the dataset word-for-word. (Default: 0.1)
dropout = 0.1

# Stop training if validation loss doesn't improve for this many epochs
early_stopping_patience = 3
early_stopping_enabled = True

# Percentage of data used for validation (e.g. 0.1 = 10%)
val_split = 0.1

# Gradient clipping limit
# Prevents exploding math errors if the AI panics during a bad training step. (Default: 1.0)
grad_clip = 1.0

# Weight decay for AdamW
weight_decay = 0.01

# Minimum learning rate ratio for Cosine Schedule
min_lr_ratio = 0.1

# Warmup steps for scheduler
warmup_steps = 100

# Random seed for reproducibility
seed = 42

[generation]
# Maximum new tokens to generate during chat
# The hard limit on how many words the AI can type in a single response before it is forced to stop typing. (Default: 256)
max_new_tokens = 256

# Softmax temperature (0.0 = greedy/deterministic, 1.0 = creative)
# Controls randomness. 0.0 forces the exact same logical answer every time. High numbers (1.0+) make the AI deeply creative, unpredictable, and sometimes chaotic. (Default: 0.8)
temperature = 0.8

# Top-p (nucleus) sampling threshold
# A layman's sanity filter. Setting this to 0.9 forces the AI to only pick the top 90% most logical words, totally deleting the bottom 10% of terrible hallucinated choices. (Default: 0.9)
top_p = 0.9

# End-of-sequence token representation
eos_token = <EOS>

[chat]
# User input prefix marker
user_prefix = [USER]
# Assistant output prefix marker
gpt_prefix = [GPT]
# Conversation template tags
human_role = [HUMAN]
gpt_role = [GPT]
system_role = [SYSTEM]
# Default system prompt injected before all conversations
default_system_prompt = You are a strict, highly capable programming assistant.

[paths]
# Relative to repository root
data_dir = data
processed_data_dir = data/processed
checkpoint_dir = model/checkpoint
tokenizer_dir = tokenizer
best_model_path = model/best/best.pt
"""

def generate_default_config(path):
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)
    with open(path, "w", encoding="utf-8") as f:
        f.write(DEFAULT_INI_TEMPLATE)

def load_config():
    if not os.path.exists(CONFIG_FILE):
        generate_default_config(CONFIG_FILE)
        
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE, encoding="utf-8")
    
    # Auto-patch logic (Preserves rich comments completely!)
    if config.has_section("System") and config.get("System", "version", fallback="0.0") != CURRENT_VERSION:
        print(f"[Config] Updating {CONFIG_FILE} to version {CURRENT_VERSION}...")
        template_lines = DEFAULT_INI_TEMPLATE.split("\n")
        
        overrides = {}
        for section in config.sections():
            overrides[section] = {}
            for key, val in config.items(section):
                overrides[section][key] = val
                
        out_lines = []
        curr_sec = None
        for line in template_lines:
            stripped = line.strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                curr_sec = stripped[1:-1]
                out_lines.append(line)
            elif curr_sec and "=" in stripped and not stripped.startswith("#"):
                key = stripped.split("=")[0].strip()
                if curr_sec in overrides and key in overrides[curr_sec] and curr_sec != "System":
                    out_lines.append(f"{key} = {overrides[curr_sec][key]}")
                else:
                    out_lines.append(line)
            else:
                out_lines.append(line)
                
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            f.write("\n".join(out_lines))
            
        config.read_string("\n".join(out_lines))

    return config

_config = load_config()

# Safe access logic mapping values structurally into the system
def _get(sec, key, fallback): return _config.get(sec, key, fallback=str(fallback)) if _config.has_option(sec, key) else fallback
def _getint(sec, key, fallback): return _config.getint(sec, key, fallback=fallback) if _config.has_option(sec, key) else fallback
def _getfloat(sec, key, fallback): return _config.getfloat(sec, key, fallback=fallback) if _config.has_option(sec, key) else fallback
def _getbool(sec, key, fallback): return _config.getboolean(sec, key, fallback=fallback) if _config.has_option(sec, key) else fallback

# Model Architecture
n_layers = _getint("model", "n_layers", 4)
n_heads = _getint("model", "n_heads", 4)
d_model = _getint("model", "d_model", 256)
d_ff = _getint("model", "d_ff", 1024)
max_seq_len = _getint("model", "max_seq_len", 512)
vocab_size = _getint("model", "vocab_size", 5000)

# Training Hyperparameters
batch_size = _getint("training", "batch_size", 8)
lr = _getfloat("training", "lr", 3e-4) 
epochs = _getint("training", "epochs", 5)
grad_accum_steps = _getint("training", "grad_accum_steps", 4)
dropout = _getfloat("training", "dropout", 0.1)
early_stopping_patience = _getint("training", "early_stopping_patience", 3)
early_stopping_enabled = _getbool("training", "early_stopping_enabled", True)
val_split = _getfloat("training", "val_split", 0.1)
grad_clip = _getfloat("training", "grad_clip", 1.0)
weight_decay = _getfloat("training", "weight_decay", 0.01)
min_lr_ratio = _getfloat("training", "min_lr_ratio", 0.1)
warmup_steps = _getint("training", "warmup_steps", 100)
seed = _getint("training", "seed", 42)

# Generation Parameters
max_new_tokens = _getint("generation", "max_new_tokens", 256)
temperature = _getfloat("generation", "temperature", 0.8)
top_p = _getfloat("generation", "top_p", 0.9)
eos_token = _get("generation", "eos_token", "<EOS>")

# Chat UI Parameters
user_prefix = _get("chat", "user_prefix", "[USER]")
gpt_prefix = _get("chat", "gpt_prefix", "[GPT]")
human_role = _get("chat", "human_role", "[HUMAN]")
gpt_role = _get("chat", "gpt_role", "[GPT]")
system_role = _get("chat", "system_role", "[SYSTEM]")
default_system_prompt = _get("chat", "default_system_prompt", "")

# Data & Checkpoints
data_dir = os.path.join(BASE_DIR, _get("paths", "data_dir", "data"))
processed_data_dir = os.path.join(BASE_DIR, _get("paths", "processed_data_dir", "data/processed"))
checkpoint_dir = os.path.join(BASE_DIR, _get("paths", "checkpoint_dir", "model/checkpoint"))
best_model_path = os.path.join(BASE_DIR, _get("paths", "best_model_path", "model/best/best.pt"))
best_model_dir = os.path.dirname(best_model_path)
tokenizer_dir = os.path.join(BASE_DIR, _get("paths", "tokenizer_dir", "tokenizer"))
pretrain_data_dir = os.path.join(data_dir, "pretrain")
sft_data_dir = os.path.join(data_dir, "sft")

REQUIRED_DIRS = [data_dir, pretrain_data_dir, sft_data_dir, processed_data_dir, checkpoint_dir, best_model_dir, tokenizer_dir]

def ensure_dirs():
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)
    for d in REQUIRED_DIRS:
        if not os.path.exists(d):
            os.makedirs(d, exist_ok=True)

if __name__ == "__main__":
    ensure_dirs()
    print(f"Configuration securely established using {CONFIG_FILE}")
