import os
import sys
import argparse
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from rich.live import Live
from rich.progress import Progress, BarColumn, TextColumn
from rich.console import Console

from image_generation.config import ImageModelConfig
from image_generation.scheduler import DDPMScheduler
from image_generation.model.vae import VAE
from image_generation.model.text_encoder import TextEncoder
from image_generation.model.diffusion import LatentDiffusion
from image_generation.image_loader import ImageDataset
from utils import safe_load

console = Console()

def train_vae(config):
    console.print("[bold cyan]Initiating VAE 'The Eyes' pre-training pipeline...[/bold cyan]")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if os.environ.get("USE_ROCM") == "1" and torch.cuda.is_available():
        device = torch.device("cuda")
    console.print(f"[bold cyan]Using device:[/bold cyan] {device}")
    
    vae = VAE(latent_channels=config.vae_channels).to(device)
    
    save_path = os.path.join(config.output_dir_model, "vae_best.pt")
    start_epoch = 0
    if os.path.exists(save_path):
        console.print(f"Resuming VAE from {save_path}...")
        checkpoint = safe_load(save_path, map_location=device)
        from utils import load_and_verify_state_dict
        if load_and_verify_state_dict(vae, checkpoint["model"], save_path):
            start_epoch = checkpoint.get("epoch", 0) + 1
            console.print(f"[bold green]Resumed at epoch {start_epoch}[/bold green]")
        
    optimizer = optim.AdamW(vae.parameters(), lr=config.learning_rate)
    from torch.optim.lr_scheduler import CosineAnnealingLR
    scheduler = CosineAnnealingLR(optimizer, T_max=config.epochs)
    
    console.print(f"Loading dataset from [dim]{config.data_dir}[/dim]...")
    full_dataset = ImageDataset(config.data_dir, config, training=True)
    if len(full_dataset) == 0:
        console.print(f"[bold red][!] No images found in {config.data_dir}. Add some to start training.[/bold red]")
        return

    val_size = max(1, int(len(full_dataset) * 0.05))
    train_size = len(full_dataset) - val_size
    train_subset, val_subset = torch.utils.data.random_split(full_dataset, [train_size, val_size])

    val_dataset = ImageDataset(config.data_dir, config, training=False,
                               samples=[full_dataset.samples[i] for i in val_subset.indices])

    train_loader = DataLoader(train_subset, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.batch_size, shuffle=False)
    import torch.nn.functional as F
    best_loss = float('inf')
    
    params_count = sum(p.numel() for p in vae.parameters()) / 1_000_000
    historical_logs = []
    
    from utils import get_system_ram_str, generate_rich_dashboard
    progress = Progress(
        TextColumn("[bold blue]Epoch {task.fields[epoch]}/{task.fields[total_epochs]}"),
        BarColumn(complete_style="cyan", finished_style="green"),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("• {task.fields[metrics]}")
    )
    task_id = progress.add_task("training", total=len(train_loader), epoch=start_epoch+1, total_epochs=config.epochs, metrics="Initializing...")

    def get_current_vram():
        if torch.cuda.is_available():
            try: return f"{torch.cuda.memory_reserved(0) / (1024**3):.1f} GB / {torch.cuda.get_device_properties(0).total_memory / (1024**3):.1f} GB"
            except: pass
        return "CPU"
        
    def render_ui(current_epoch, current_metrics):
        best_str = f"{best_loss:.4f}" if best_loss != float('inf') else "N/A"
        rows = [
            (f"[bold cyan]Mode:[/bold cyan] VAE", f"[bold cyan]VRAM:[/bold cyan] {get_current_vram()}", f"[bold cyan]RAM:[/bold cyan] {get_system_ram_str()}"),
            (f"[bold cyan]Architecture:[/bold cyan] {params_count:.2f}M Params", f"[bold cyan]Target:[/bold cyan] {config.image_width}x{config.image_height}", f"[bold cyan]Best Loss:[/bold cyan] {best_str}")
        ]
        progress.update(task_id, epoch=current_epoch+1, total_epochs=config.epochs, metrics=current_metrics)
        return generate_rich_dashboard("Diffusion Training Studio", rows, historical_logs, progress)

    os.system('cls' if os.name == 'nt' else 'clear')
    live = Live(render_ui(start_epoch, "Initializing..."), refresh_per_second=4)
    live.start()
    
    try:
        for epoch in range(start_epoch, config.epochs):
            vae.train()
            total_loss = 0.0
            total_recon = 0.0
            total_kl = 0.0
            _last_ui = time.time()
            
            progress.reset(task_id, total=len(train_loader))
            
            for i, (img_b, _) in enumerate(train_loader):
                img_b = img_b.to(device)
                optimizer.zero_grad()
                reconstruction, mu, logvar = vae(img_b)
                
                recon_loss = F.mse_loss(reconstruction, img_b)
                kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / img_b.size(0)
                loss = recon_loss + config.kl_weight * kl_loss
                
                loss.backward()
                torch.nn.utils.clip_grad_norm_(vae.parameters(), getattr(config, 'grad_clip', 1.0))
                optimizer.step()
                
                total_loss += loss.item()
                total_recon += recon_loss.item()
                total_kl += kl_loss.item()
                
                m_str = f"Loss: {loss.item():.4f} | Recon: {recon_loss.item():.4f} | LR: {optimizer.param_groups[0]['lr']:.2e}"
                progress.update(task_id, advance=1)
                _now = time.time()
                if _now - _last_ui >= 0.25:
                    live.update(render_ui(epoch, m_str))
                    _last_ui = _now
                                 
            avg_loss = total_loss / len(train_loader)
            scheduler.step()
            
            vae.eval()
            val_total = 0.0
            val_count = 0
            with torch.no_grad():
                for v_img_b, _ in val_loader:
                    v_img_b = v_img_b.to(device)
                    v_reconstruction, v_mu, v_logvar = vae(v_img_b)
                    v_recon = F.mse_loss(v_reconstruction, v_img_b)
                    v_kl = -0.5 * torch.sum(1 + v_logvar - v_mu.pow(2) - v_logvar.exp()) / v_img_b.size(0)
                    val_total += (v_recon + config.kl_weight * v_kl).item()
                    val_count += 1
            val_loss = val_total / max(val_count, 1)
            
            is_best = False
            if val_loss < best_loss:
                best_loss = val_loss
                is_best = True
                torch.save({"model": vae.state_dict(), "epoch": epoch, "loss": best_loss}, save_path)
                
            save_interval = getattr(config, 'save_interval', 10)
            checkpoint_tag = ""
            if save_interval > 0 and (epoch + 1) % save_interval == 0:
                torch.save({"model": vae.state_dict(), "epoch": epoch, "loss": best_loss}, save_path.replace("best.pt", f"ep{epoch+1}.pt"))
                checkpoint_tag = " [bold cyan][SAVED][/bold cyan]"
                
            best_tag = " [bold yellow][BEST][/bold yellow]" if is_best else ""
            historical_logs.append(f"[bold green]✓ Epoch {epoch+1}:[/bold green] [T: {avg_loss:.4f}, V: {val_loss:.4f}] | Recon: {total_recon/len(train_loader):.4f}{best_tag}{checkpoint_tag}")
            live.update(render_ui(epoch, "Epoch Complete\n"))
                
    except KeyboardInterrupt:
        historical_logs.append("[bold red][!] Training paused by user.[/bold red]")
        live.update(render_ui(epoch, "Paused"))
        torch.save({"model": vae.state_dict(), "epoch": epoch if 'epoch' in locals() else start_epoch, "loss": avg_loss if 'avg_loss' in locals() else best_loss}, save_path.replace(".pt", "_interrupted.pt"))

    live.stop()
    console.print(f"\n[bold green]VAE Training completed.[/bold green] Best Loss: {best_loss:.4f}\n")

def train_diffusion(config):
    console.print("[bold cyan]Initiating Latent Diffusion 'The Brain' & Text Encoder 'The Ears' joint training...[/bold cyan]")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if os.environ.get("USE_ROCM") == "1" and torch.cuda.is_available():
        device = torch.device("cuda")
    console.print(f"[bold cyan]Using device:[/bold cyan] {device}")
    
    import config as text_config
    from tokenizer.bpe import BPETokenizer
    tok_path = os.path.join(text_config.tokenizer_dir, "tokenizer.json")
    if not os.path.exists(tok_path):
        console.print(f"[bold red][!] Tokenizer missing at {tok_path}. Cannot train text embeddings.[/bold red]")
        return
    tokenizer = BPETokenizer.load(tok_path)
    config.vocab_size = len(tokenizer.vocab)
    
    vae = VAE(latent_channels=config.vae_channels).to(device)
    vae_path = os.path.join(config.output_dir_model, "vae_best.pt")
    if not os.path.exists(vae_path):
        console.print(f"[bold red][!] Frozen VAE missing at {vae_path}. You must finish Option 6 first.[/bold red]")
        return
    from utils import load_and_verify_state_dict
    if not load_and_verify_state_dict(vae, safe_load(vae_path, map_location=device)["model"], vae_path):
        console.print("[bold red][!] Incompatible frozen VAE moved to archive. Please run Option 6 again.[/bold red]")
        return
    vae.eval()
    for param in vae.parameters():
        param.requires_grad = False
        
    if config.vocab_size == 0:
        console.print("[bold red][!] FATAL: vocab_size is 0. The tokenizer did not load correctly. Cannot construct TextEncoder.[/bold red]")
        return

    text_encoder = TextEncoder(config.vocab_size, config.text_embedding_dim, config.text_max_seq_len).to(device)
    diffusion = LatentDiffusion(in_channels=config.diffusion_channels, text_embed_dim=config.text_embedding_dim).to(device)
    scheduler = DDPMScheduler()
    
    params = list(text_encoder.parameters()) + list(diffusion.parameters())
    optimizer = optim.AdamW(params, lr=config.learning_rate)
    from torch.optim.lr_scheduler import CosineAnnealingLR
    scheduler_lr = CosineAnnealingLR(optimizer, T_max=config.epochs)
    
    save_path = os.path.join(config.output_dir_model, "diffusion_best.pt")
    start_epoch = 0
    if os.path.exists(save_path):
        chk = safe_load(save_path, map_location=device)
        from utils import load_and_verify_state_dict
        if load_and_verify_state_dict(text_encoder, chk["text_encoder"], save_path) and load_and_verify_state_dict(diffusion, chk["diffusion"], save_path):
            start_epoch = chk.get("epoch", 0) + 1
            console.print(f"[bold green]Resumed diffusion from {save_path} at epoch {start_epoch}[/bold green]")
        else:
            console.print("[bold yellow]Starting diffusion training from scratch due to incompatible checkpoint.[/bold yellow]")
        
    full_dataset = ImageDataset(config.data_dir, config, training=True, tokenizer=tokenizer, max_seq_len=config.text_max_seq_len)
    if len(full_dataset) == 0:
        console.print(f"[bold red][!] No images found in {config.data_dir}. Add some to start training.[/bold red]")
        return

    val_size = max(1, int(len(full_dataset) * 0.05))
    train_size = len(full_dataset) - val_size
    train_subset, val_subset = torch.utils.data.random_split(full_dataset, [train_size, val_size])

    val_dataset = ImageDataset(config.data_dir, config, training=False,
                               samples=[full_dataset.samples[i] for i in val_subset.indices],
                               tokenizer=tokenizer, max_seq_len=config.text_max_seq_len)

    train_loader = DataLoader(train_subset, batch_size=config.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.batch_size, shuffle=False)
    import torch.nn.functional as F
    best_loss = float('inf')
    
    params_count = sum(p.numel() for p in diffusion.parameters()) / 1_000_000
    historical_logs = []

    from utils import get_system_ram_str, generate_rich_dashboard
    progress = Progress(
        TextColumn("[bold blue]Epoch {task.fields[epoch]}/{task.fields[total_epochs]}"),
        BarColumn(complete_style="cyan", finished_style="green"),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("• {task.fields[metrics]}")
    )
    task_id = progress.add_task("training", total=len(train_loader), epoch=start_epoch+1, total_epochs=config.epochs, metrics="Initializing...")

    def get_current_vram():
        if torch.cuda.is_available():
            try: return f"{torch.cuda.memory_reserved(0) / (1024**3):.1f} GB / {torch.cuda.get_device_properties(0).total_memory / (1024**3):.1f} GB"
            except: pass
        return "CPU"
        
    def render_ui(current_epoch, current_metrics):
        best_str = f"{best_loss:.4f}" if best_loss != float('inf') else "N/A"
        rows = [
            (f"[bold cyan]Mode:[/bold cyan] DIFFUSION", f"[bold cyan]VRAM:[/bold cyan] {get_current_vram()}", f"[bold cyan]RAM:[/bold cyan] {get_system_ram_str()}"),
            (f"[bold cyan]Architecture:[/bold cyan] {params_count:.2f}M Params", f"[bold cyan]Target:[/bold cyan] {config.image_width}x{config.image_height}", f"[bold cyan]Best Loss:[/bold cyan] {best_str}")
        ]
        progress.update(task_id, epoch=current_epoch+1, total_epochs=config.epochs, metrics=current_metrics)
        return generate_rich_dashboard("Diffusion Training Studio", rows, historical_logs, progress)

    os.system('cls' if os.name == 'nt' else 'clear')
    live = Live(render_ui(start_epoch, "Initializing..."), refresh_per_second=4)
    live.start()
    
    try:
        for epoch in range(start_epoch, config.epochs):
            text_encoder.train()
            diffusion.train()
            total_loss = 0.0
            _last_ui = time.time()
            
            progress.reset(task_id, total=len(train_loader))
            
            for i, (img_b, input_ids) in enumerate(train_loader):
                img_b = img_b.to(device)
                input_ids = input_ids.to(device)
                b_size = img_b.size(0)
                
                # Classifier-Free Guidance (CFG): 10% dropout
                drop_prob = 0.1
                mask = torch.rand(b_size, device=device) < drop_prob
                if mask.any():
                    input_ids = input_ids.clone()
                    input_ids[mask] = 0 # 0 is padding/unconditional
                
                optimizer.zero_grad()
                
                context = text_encoder(input_ids)
                
                with torch.no_grad():
                    latents, _, _ = vae.encode(img_b)
                
                noise = torch.randn_like(latents)
                timesteps = torch.randint(0, scheduler.num_train_timesteps, (b_size,), device=device).long()
                noisy_latents = scheduler.add_noise(latents, noise, timesteps)
                
                pred_noise = diffusion(noisy_latents, timesteps, context)
                loss = F.mse_loss(pred_noise, noise)
                
                loss.backward()
                torch.nn.utils.clip_grad_norm_(params, getattr(config, 'grad_clip', 1.0))
                optimizer.step()
                
                total_loss += loss.item()
                m_str = f"Loss: {loss.item():.4f} | LR: {optimizer.param_groups[0]['lr']:.2e}"
                progress.update(task_id, advance=1)
                _now = time.time()
                if _now - _last_ui >= 0.25:
                    live.update(render_ui(epoch, m_str))
                    _last_ui = _now
                
            avg_loss = total_loss / len(train_loader)
            scheduler_lr.step()
            
            text_encoder.eval()
            diffusion.eval()
            val_total = 0.0
            val_count = 0
            
            # Make validation deterministic for consistent metric comparison
            torch.manual_seed(42)
            
            with torch.no_grad():
                for v_img_b, v_input_ids in val_loader:
                    v_img_b = v_img_b.to(device)
                    v_input_ids = v_input_ids.to(device)

                    v_context = text_encoder(v_input_ids)
                    # FIXED: VAE.encode returns (z, mu, logvar) - no .latent_dist
                    v_latents, _, _ = vae.encode(v_img_b)   # <-- Fixed line
                    v_noise = torch.randn_like(v_latents)
                    v_timesteps = torch.randint(0, scheduler.num_train_timesteps, (v_img_b.size(0),), device=device).long()
                    v_noisy_latents = scheduler.add_noise(v_latents, v_noise, v_timesteps)

                    v_pred_noise = diffusion(v_noisy_latents, v_timesteps, v_context)
                    val_total += F.mse_loss(v_pred_noise, v_noise).item()
                    val_count += 1
            val_loss = val_total / max(val_count, 1)
            
            is_best = False
            if val_loss < best_loss:
                best_loss = val_loss
                is_best = True
                torch.save({"text_encoder": text_encoder.state_dict(), "diffusion": diffusion.state_dict(), "epoch": epoch, "loss": best_loss}, save_path)
                
            save_interval = getattr(config, 'save_interval', 10)
            checkpoint_tag = ""
            if save_interval > 0 and (epoch + 1) % save_interval == 0:
                torch.save({"text_encoder": text_encoder.state_dict(), "diffusion": diffusion.state_dict(), "epoch": epoch, "loss": best_loss}, save_path.replace("best.pt", f"ep{epoch+1}.pt"))
                checkpoint_tag = " [bold cyan][SAVED][/bold cyan]"
                
            best_tag = " [bold yellow][BEST][/bold yellow]" if is_best else ""
            historical_logs.append(f"[bold green]✓ Epoch {epoch+1}:[/bold green] [T: {avg_loss:.4f}, V: {val_loss:.4f}]{best_tag}{checkpoint_tag}")
            live.update(render_ui(epoch, "Epoch Complete\n"))
                
    except KeyboardInterrupt:
        historical_logs.append("[bold red][!] Training paused by user.[/bold red]")
        live.update(render_ui(epoch, "Paused"))
        
    live.stop()
    console.print(f"\n[bold green]Diffusion Training completed.[/bold green] Best Loss: {best_loss:.4f}\n")


def _dry_run(config):
    print("Running initial sanity check on architectures...")
    vae = VAE(latent_channels=config.vae_channels)
    
    dummy_imgs = torch.randn(2, 3, config.image_height, config.image_width)
    latents, mu, logvar = vae.encode(dummy_imgs)
    rec = vae.decode(latents)
    assert rec.shape == dummy_imgs.shape, "Decoder output shape mismatch."
    assert latents.shape == (2, config.vae_channels, config.latent_height, config.latent_width), "Latent math mismatch."
    console.print("[bold green]Shape checks passed perfectly. VAE is functional.[/bold green]")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", type=str, choices=["vae", "diffusion", "dry-run"], default="dry-run")
    args = parser.parse_args()
    
    config = ImageModelConfig.load()
    
    if args.mode == "vae":
        train_vae(config)
    elif args.mode == "diffusion":
        train_diffusion(config)
    elif args.mode == "dry-run":
        _dry_run(config)