import os
import sys
import torch

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rich.console import Console
from image_generation.config import ImageModelConfig
from image_generation.model.vae import VAE
from image_generation.model.text_encoder import TextEncoder
from image_generation.model.diffusion import LatentDiffusion
from image_generation.scheduler import DDPMScheduler
import config as text_config
from tokenizer.bpe import BPETokenizer
from utils import safe_load

console = Console()

class ModelBridge:
    def __init__(self, image_pipeline_config=None):
        self.image_config = image_pipeline_config or ImageModelConfig.load()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.scheduler = DDPMScheduler()
        
        self.is_loaded = False
        self.vae = None
        self.text_encoder = None
        self.diffusion = None
        self.tokenizer = None

    def load_models_if_needed(self):
        if self.is_loaded:
            return True
            
        if self.vae is None:
            console.print("\n[bold cyan][Bridge][/bold cyan] Waking up Generation Pipeline. Loading models from disk...")
            vae_path = os.path.join(self.image_config.output_dir_model, "vae_best.pt")
            diff_path = os.path.join(self.image_config.output_dir_model, "diffusion_best.pt")
            tok_path = os.path.join(text_config.tokenizer_dir, "tokenizer.json")
            
            if not os.path.exists(vae_path) or not os.path.exists(diff_path) or not os.path.exists(tok_path):
                console.print("[bold red][Bridge] ERROR:[/bold red] Image models not found. Train options 6 and 7 first.")
                return False
                
            self.tokenizer = BPETokenizer.load(tok_path)
            self.image_config.vocab_size = len(self.tokenizer.vocab)

            if self.image_config.vocab_size == 0:
                console.print("[bold red][Bridge] FATAL:[/bold red] vocab_size is 0 after loading tokenizer.")
                return False
                
            self.vae = VAE(latent_channels=self.image_config.vae_channels)
            self.vae.load_state_dict(safe_load(vae_path, map_location="cpu")["model"])
            self.vae.eval()
            
            chk = safe_load(diff_path, map_location="cpu")
            self.text_encoder = TextEncoder(
                self.image_config.vocab_size,
                self.image_config.text_embedding_dim,
                self.image_config.text_max_seq_len
            )
            self.text_encoder.load_state_dict(chk["text_encoder"])
            self.text_encoder.eval()
            
            self.diffusion = LatentDiffusion(
                in_channels=self.image_config.diffusion_channels,
                text_embed_dim=self.image_config.text_embedding_dim
            )
            self.diffusion.load_state_dict(chk["diffusion"])
            self.diffusion.eval()
        else:
            console.print("\n[bold cyan][Bridge][/bold cyan] Pipeline already initialised. Hot-swapping to device...")

        self.vae.to(self.device)
        self.text_encoder.to(self.device)
        self.diffusion.to(self.device)
        
        self.is_loaded = True
        return True
        
    def unload_models(self):
        if not self.is_loaded:
            return
        
        self.vae.to("cpu")
        self.text_encoder.to("cpu")
        self.diffusion.to("cpu")
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            
        self.is_loaded = False
        console.print("[bold cyan][Bridge][/bold cyan] Pipeline safely offloaded from device memory.")

    def process_chat_message(self, message):
        """
        Routes to the image pipeline only on an explicit /imagine <prompt> command.
        Returns a typed dict: {"type": "text"|"image"|"error", "content"|"prompt": ...}
        """
        if not message or not isinstance(message, str):
            return {"type": "text", "content": message}

        trigger = "/imagine "
        if trigger in message:
            start_idx = message.find(trigger) + len(trigger)
            prompt = message[start_idx:].strip()
            if prompt:
                return self._generate_image(prompt)
            # /imagine was present but no prompt followed it
            return {"type": "error", "content": "No prompt provided after /imagine."}

        return {"type": "text", "content": message}

    def _generate_image(self, prompt: str):
        """Internal image generation logic."""
        console.print(f"\n[bold cyan][Bridge][/bold cyan] Starting image generation for: [white]'{prompt}'[/white]")
        
        if not self.load_models_if_needed():
            return {"type": "error", "content": "Models missing. Train options 6 and 7 first."}
            
        try:
            with torch.no_grad():
                tokens = self.tokenizer.encode(prompt)
                if len(tokens) > self.image_config.text_max_seq_len:
                    tokens = tokens[:self.image_config.text_max_seq_len]
                else:
                    tokens = tokens + [0] * (self.image_config.text_max_seq_len - len(tokens))
                input_ids = torch.tensor([tokens], dtype=torch.long, device=self.device)
                cond_context = self.text_encoder(input_ids)
                
                uncond_ids = torch.zeros_like(input_ids)
                uncond_context = self.text_encoder(uncond_ids)
                
                context = torch.cat([uncond_context, cond_context])
                
                latents = torch.randn(
                    (1, self.image_config.vae_channels,
                     self.image_config.latent_height,
                     self.image_config.latent_width),
                    device=self.device
                )
                
                inference_steps = self.image_config.inference_steps
                cfg_scale       = self.image_config.cfg_scale
                step_ratio      = self.scheduler.num_train_timesteps // inference_steps
                
                console.print(f"[bold cyan][Bridge][/bold cyan] Executing {inference_steps}-step DDIM CFG denoising...")
                
                from rich.progress import track
                times = list(reversed([i * step_ratio for i in range(inference_steps)]))
                
                for i, t in enumerate(track(times, description="[cyan]Generating...", transient=True)):
                    latent_model_input = torch.cat([latents, latents])
                    timesteps = torch.tensor([t, t], device=self.device).long()
                    
                    noise_pred = self.diffusion(latent_model_input, timesteps, context)
                    
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + cfg_scale * (noise_pred_text - noise_pred_uncond)
                    
                    prev_t  = times[i + 1] if i < len(times) - 1 else -1
                    latents = self.scheduler.step_ddim(
                        model_output=noise_pred, timestep=t,
                        prev_timestep=prev_t, sample=latents
                    )
                
                console.print("[bold cyan][Bridge][/bold cyan] Denoising complete. Reconstructing via VAE...")
                image_tensor = self.vae.decode(latents)
                image_tensor = (image_tensor / 2 + 0.5).clamp(0, 1)
                image_tensor = image_tensor.cpu().permute(0, 2, 3, 1).numpy()[0]
                
                from PIL import Image
                import numpy as np
                img = Image.fromarray((image_tensor * 255).astype(np.uint8))
                
                os.makedirs(self.image_config.output_dir_image, exist_ok=True)
                path = os.path.join(self.image_config.output_dir_image, "latest_generation.jpg")
                img.save(path)
                console.print(f"[bold green][Bridge][/bold green] Image saved to: [dim]{path}[/dim]")
                
        finally:
            self.unload_models()
        
        return {
            "type": "image",
            "prompt": prompt,
            "status": "passed_to_image_model"
        }


class ModelBridge:
    def __init__(self, image_pipeline_config=None):
        self.image_config = image_pipeline_config or ImageModelConfig.load()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.scheduler = DDPMScheduler()
        
        self.is_loaded = False
        self.vae = None
        self.text_encoder = None
        self.diffusion = None
        self.tokenizer = None

    def load_models_if_needed(self):
        if self.is_loaded:
            return True
            
        if self.vae is None:
            print("\n[Bridge] Waking up Generation Pipeline. Loading Models from Disk...")
            vae_path = os.path.join(self.image_config.output_dir_model, "vae_best.pt")
            diff_path = os.path.join(self.image_config.output_dir_model, "diffusion_best.pt")
            tok_path = os.path.join(text_config.tokenizer_dir, "tokenizer.json")
            
            if not os.path.exists(vae_path) or not os.path.exists(diff_path) or not os.path.exists(tok_path):
                print("[Bridge] ERROR: You must train Option 6 and Option 7 first! Models missing.")
                return False
                
            self.tokenizer = BPETokenizer.load(tok_path)
            self.image_config.vocab_size = len(self.tokenizer.vocab)

            if self.image_config.vocab_size == 0:
                print("[Bridge] FATAL: vocab_size is 0 after loading tokenizer. Aborting.")
                return False
                
            self.vae = VAE(latent_channels=self.image_config.vae_channels)
            self.vae.load_state_dict(safe_load(vae_path, map_location="cpu")["model"])
            self.vae.eval()
            
            chk = safe_load(diff_path, map_location="cpu")
            self.text_encoder = TextEncoder(self.image_config.vocab_size, self.image_config.text_embedding_dim, self.image_config.text_max_seq_len)
            self.text_encoder.load_state_dict(chk["text_encoder"])
            self.text_encoder.eval()
            
            self.diffusion = LatentDiffusion(in_channels=self.image_config.diffusion_channels, text_embed_dim=self.image_config.text_embedding_dim)
            self.diffusion.load_state_dict(chk["diffusion"])
            self.diffusion.eval()
        else:
            print("\n[Bridge] Waking up Generation Pipeline. Hot-swapping to VRAM...")

        self.vae.to(self.device)
        self.text_encoder.to(self.device)
        self.diffusion.to(self.device)
        
        self.is_loaded = True
        return True
        
    def unload_models(self):
        if not self.is_loaded:
            return
        
        self.vae.to("cpu")
        self.text_encoder.to("cpu")
        self.diffusion.to("cpu")
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            
        self.is_loaded = False
        print("[Bridge] Pipeline safely offloaded from VRAM.")

    def process_chat_message(self, message):
        """
        Safer bridge for small models.
        - Only triggers on explicit /imagine from USER messages.
        - Ignores /imagine coming from the model's own output to prevent spam.
        - Natural language detection is disabled until the model is smarter.
        """
        if not message or not isinstance(message, str):
            return {"type": "text", "content": message}

        # Only respond to explicit /imagine command from the USER
        # (We ignore it if it comes from the model to prevent hallucinated triggers)
        trigger = "/imagine "
        if trigger in message:
            # Simple check: if the message starts with [USER] or contains user-like prefix, allow it
            if trigger in message:
                start_idx = message.find(trigger) + len(trigger)
                prompt = message[start_idx:].strip()
            if prompt:
                return self._generate_image(prompt)
            
            # If it came from the model, just treat it as normal text for now
            return {"type": "text", "content": message}

        # No image request detected
        return {
            "type": "text",
            "content": message
        }

    def _generate_image(self, prompt: str):
        """Internal image generation logic"""
        print(f"\n[Bridge] Starting image generation for: '{prompt}'")
        
        if not self.load_models_if_needed():
            return {"type": "error", "content": "Models missing."}
            
        try:
            with torch.no_grad():
                tokens = self.tokenizer.encode(prompt)
                if len(tokens) > self.image_config.text_max_seq_len:
                    tokens = tokens[:self.image_config.text_max_seq_len]
                else:
                    tokens = tokens + [0] * (self.image_config.text_max_seq_len - len(tokens))
                input_ids = torch.tensor([tokens], dtype=torch.long, device=self.device)
                cond_context = self.text_encoder(input_ids)
                
                uncond_ids = torch.zeros_like(input_ids)
                uncond_context = self.text_encoder(uncond_ids)
                
                context = torch.cat([uncond_context, cond_context])
                
                latents = torch.randn((1, self.image_config.vae_channels, 
                                     self.image_config.latent_height, 
                                     self.image_config.latent_width), device=self.device)
                
                inference_steps = self.image_config.inference_steps
                cfg_scale = self.image_config.cfg_scale
                step_ratio = self.scheduler.num_train_timesteps // inference_steps
                
                from rich import print as rprint
                rprint(f"[bold cyan][Bridge][/bold cyan] Executing {inference_steps}-Step DDIM CFG Denoising...")
                
                from rich.progress import track
                times = list(reversed([i * step_ratio for i in range(inference_steps)]))
                
                for i, t in enumerate(track(times, description="[cyan]Generating Image...", transient=True)):
                    latent_model_input = torch.cat([latents, latents])
                    timesteps = torch.tensor([t, t], device=self.device).long()
                    
                    noise_pred = self.diffusion(latent_model_input, timesteps, context)
                    
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + cfg_scale * (noise_pred_text - noise_pred_uncond)
                    
                    prev_t = times[i + 1] if i < len(times) - 1 else -1
                    latents = self.scheduler.step_ddim(model_output=noise_pred, timestep=t, prev_timestep=prev_t, sample=latents)
                
                print("[Bridge] Denoising complete. Reconstructing via VAE...")
                image_tensor = self.vae.decode(latents)
                image_tensor = (image_tensor / 2 + 0.5).clamp(0, 1)
                image_tensor = image_tensor.cpu().permute(0, 2, 3, 1).numpy()[0]
                
                from PIL import Image
                import numpy as np
                image_np = (image_tensor * 255).astype(np.uint8)
                img = Image.fromarray(image_np)
                
                if not os.path.exists(self.image_config.output_dir_image):
                    os.makedirs(self.image_config.output_dir_image, exist_ok=True)
                path = os.path.join(self.image_config.output_dir_image, "latest_generation.jpg")
                img.save(path)
                print(f"[Bridge] Image saved to: {path}")
                
        finally:
            self.unload_models()
        
        return {
            "type": "image",
            "prompt": prompt,
            "status": "passed_to_image_model"
        }