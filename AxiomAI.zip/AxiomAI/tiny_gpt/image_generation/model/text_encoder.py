import torch
import torch.nn as nn

class TextEncoder(nn.Module):
    def __init__(self, vocab_size, embed_dim, max_seq_len):
        super().__init__()
        self.token_embedding = nn.Embedding(vocab_size, embed_dim)
        self.position_embedding = nn.Embedding(max_seq_len, embed_dim)
        
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=4, batch_first=True)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=2, enable_nested_tensor=False)
        
    def forward(self, input_ids):
        B, seq_len = input_ids.size()
        positions = torch.arange(0, seq_len, dtype=torch.long, device=input_ids.device)
        
        pad_mask = (input_ids == 0)
        
        # PyTorch returns NaN if a sequence is 100% masked out.
        # For completely unconditional vectors (all 0s), unmask the root token.
        all_padded = pad_mask.all(dim=-1)
        pad_mask[all_padded, 0] = False
        
        x = self.token_embedding(input_ids) + self.position_embedding(positions)
        x = self.transformer(x, src_key_padding_mask=pad_mask)
        return x
