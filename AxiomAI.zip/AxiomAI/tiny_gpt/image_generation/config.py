import os
import configparser
import dataclasses
from dataclasses import dataclass

def get_root_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CURRENT_VERSION = "1.3"

DEFAULT_IMAGE_INI = f"""[System]
# Configuration file version (Do not modify this manually. Used for auto-patching when updates release)
version = {CURRENT_VERSION}

[dimensions]
# Final width of the generated image (Must be divisible by vae_downsample_factor)
# NOTE: Huge resolutions require immense GPU VRAM. Start small (e.g. 144x96) and scale up if your hardware handles it.
image_width = 144

# Final height of the generated image
image_height = 96

[text_encoder]
# Overridden at runtime from the loaded tokenizer. Set to 0 as a placeholder.
vocab_size = 0

# Size of the context representation
# This dictates how deeply the Diffusion engine translates words into visual meaning. Larger embeddings capture complex prompts better, but bloat memory heavily.
text_embedding_dim = 256

# Maximum tokens the prompt context uses
# The physical limit on how long your text prompts can be when generating an image. 77 is the industry standard.
text_max_seq_len = 77

[vae]
# Depth of the mathematical Latent matrix
# Controls the color density representation during generation. 4 is the universal standard for Latent Diffusion.
vae_channels = 4

# How aggressively the VAE compresses images before the Diffusion Model processes them
# The VAE has 2 strided-conv downsample layers, giving a true spatial compression factor of 4.
# A 144x96 image becomes a 36x24 latent grid.
vae_downsample_factor = 4

# Regularization weight for KL divergence in the VAE loss.
# Balances reconstruction quality against latent space regularity.
# Values too low produce sharp reconstructions but an unorganized latent space
# that the diffusion model cannot sample from reliably.
kl_weight = 1e-4

[diffusion]
# Channel depth of the mapping block (Matches vae_channels usually)
diffusion_channels = 4

# UNet depth is fixed at 3 levels (64, 128, 256) in the architecture.

# Noise sequence steps for training
num_timesteps = 1000

# Number of denoising steps used during image generation inference
inference_steps = 50

# Classifier-Free Guidance scale for inference
# Higher values produce images more tightly bound to the prompt but may oversaturate.
cfg_scale = 7.5

[training]
# Memory load per step
# How many pictures the GPU processes simultaneously. Weak GPUs must keep this tightly clamped to 1 or 2, or they will crash OutOfMemory.
batch_size = 8

# Execution magnitude 
# The pace at which the AI learns structures. If images come out as scrambled neon blurs, this might be too high.
learning_rate = 1e-4

# Number of cycles
# The amount of complete loops the system does across your entire Photos directory.
epochs = 500

# Maximum gradient limit
# Truncates explosive mathematical spikes during early noisy timesteps ensuring stable loss lines.
grad_clip = 1.0

# Fixed Interval Savings
# Brutally dumps a persistent checkpoint every N epochs for manual visual verification regardless of the loss line.
save_interval = 10

[paths]
# Input directory holding raw image files (Relative to the root TinyGPT directory)
data_dir = Photos
# Output directory for saved model artifacts (.pt)
output_dir_model = image_gen_model
# Output directory for generated image results
output_dir_image = out_image
"""

@dataclass
class ImageModelConfig:
    image_width: int = 144
    image_height: int = 96
    vocab_size: int = 0
    text_embedding_dim: int = 256
    text_max_seq_len: int = 77
    vae_channels: int = 4
    vae_downsample_factor: int = 4
    kl_weight: float = 1e-4
    diffusion_channels: int = 4
    num_timesteps: int = 1000
    inference_steps: int = 50
    cfg_scale: float = 7.5
    batch_size: int = 8
    learning_rate: float = 1e-4
    epochs: int = 500
    grad_clip: float = 1.0
    save_interval: int = 10
    data_dir: str = "Photos"
    output_dir_model: str = "model"
    output_dir_image: str = "out_image"

    @classmethod
    def load(cls):
        config_path = os.path.join(get_root_dir(), "config", "image_config.ini")
        instance = cls()
        
        if not os.path.exists(config_path):
            with open(config_path, "w", encoding="utf-8") as f:
                f.write(DEFAULT_IMAGE_INI)
                
        config = configparser.ConfigParser()
        config.read(config_path, encoding="utf-8")

        if config.has_section("System") and config.get("System", "version", fallback="0.0") != CURRENT_VERSION:
            print(f"[Config] Updating {config_path} to version {CURRENT_VERSION}...")
            template_lines = DEFAULT_IMAGE_INI.split("\n")
            overrides = {}
            for section in config.sections():
                overrides[section] = {}
                for key, val in config.items(section):
                    overrides[section][key] = val
                    
            out_lines = []
            curr_sec = None
            for line in template_lines:
                stripped = line.strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    curr_sec = stripped[1:-1]
                    out_lines.append(line)
                elif curr_sec and "=" in stripped and not stripped.startswith("#"):
                    key = stripped.split("=")[0].strip()
                    if curr_sec in overrides and key in overrides[curr_sec] and curr_sec != "System":
                        out_lines.append(f"{key} = {overrides[curr_sec][key]}")
                    else:
                        out_lines.append(line)
                else:
                    out_lines.append(line)
                    
            with open(config_path, "w", encoding="utf-8") as f:
                f.write("\n".join(out_lines))
                
            config.read_string("\n".join(out_lines))
            
        for field in dataclasses.fields(instance):
            key = field.name
            target_type = field.type
            val_found = None
            for section in config.sections():
                if config.has_option(section, key):
                    if target_type is int:
                        val_found = config.getint(section, key)
                    elif target_type is float:
                        val_found = config.getfloat(section, key)
                    elif target_type is str:
                        val_found = config.get(section, key)
                    elif target_type is bool:
                        val_found = config.getboolean(section, key)
                    break
                    
            if val_found is not None:
                setattr(instance, key, val_found)

        instance._validate()
        return instance

    def save(self):
        config_path = os.path.join(get_root_dir(), "config", "image_config.ini")
        config = configparser.ConfigParser()
        
        # Preserve versioning info if it exists, otherwise use current
        current_v = CURRENT_VERSION
        if os.path.exists(config_path):
            tmp = configparser.ConfigParser()
            tmp.read(config_path, encoding="utf-8")
            if tmp.has_option("System", "version"):
                current_v = tmp.get("System", "version")

        config.add_section("System")
        config.set("System", "version", current_v)

        config.add_section("dimensions")
        config.set("dimensions", "image_width", str(self.image_width))
        config.set("dimensions", "image_height", str(self.image_height))

        config.add_section("text_encoder")
        config.set("text_encoder", "vocab_size", str(self.vocab_size))
        config.set("text_encoder", "text_embedding_dim", str(self.text_embedding_dim))
        config.set("text_max_seq_len", "text_max_seq_len", str(self.text_max_seq_len)) # section name check... wait

        # Correction: Section names should match DEFAULT_IMAGE_INI
        # Let's rebuild the mapping properly
        
        sections = {
            "dimensions": ["image_width", "image_height"],
            "text_encoder": ["vocab_size", "text_embedding_dim", "text_max_seq_len"],
            "vae": ["vae_channels", "vae_downsample_factor", "kl_weight"],
            "diffusion": ["diffusion_channels", "num_timesteps", "inference_steps", "cfg_scale"],
            "training": ["batch_size", "learning_rate", "epochs", "grad_clip", "save_interval"],
            "paths": ["data_dir", "output_dir_model", "output_dir_image"]
        }

        for sec_name, keys in sections.items():
            if not config.has_section(sec_name):
                config.add_section(sec_name)
            for k in keys:
                config.set(sec_name, k, str(getattr(self, k)))

        with open(config_path, "w", encoding="utf-8") as f:
            config.write(f)

    def _validate(self):
        if self.image_width % self.vae_downsample_factor != 0:
            raise ValueError(f"image_width ({self.image_width}) must be fully divisible by vae_downsample_factor ({self.vae_downsample_factor})")
        if self.image_height % self.vae_downsample_factor != 0:
            raise ValueError(f"image_height ({self.image_height}) must be fully divisible by vae_downsample_factor ({self.vae_downsample_factor})")
            
        real_model_out = os.path.join(get_root_dir(), self.output_dir_model)
        if not os.path.exists(real_model_out):
            os.makedirs(real_model_out, exist_ok=True)
            
        real_image_out = os.path.join(get_root_dir(), self.output_dir_image)
        if not os.path.exists(real_image_out):
            os.makedirs(real_image_out, exist_ok=True)
            
    @property
    def latent_width(self) -> int:
        return self.image_width // self.vae_downsample_factor
        
    @property
    def latent_height(self) -> int:
        return self.image_height // self.vae_downsample_factor
