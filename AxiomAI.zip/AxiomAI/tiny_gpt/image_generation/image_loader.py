import os
import torch
from torch.utils.data import Dataset
from PIL import Image

try:
    import torchvision.transforms as T
except ImportError:
    raise ImportError("[!] torchvision is required. Install it with: pip install torchvision")

class ImageDataset(Dataset):
    def __init__(self, data_dir, config, training=True, samples=None, tokenizer=None, max_seq_len=None):
        self.data_dir = data_dir
        self.config = config
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len if max_seq_len is not None else getattr(config, 'text_max_seq_len', 77)

        transforms = [
            T.Resize((self.config.image_height, self.config.image_width)),
        ]
        if training:
            transforms.append(T.RandomHorizontalFlip())
        transforms.extend([
            T.ToTensor(),
            T.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        ])
        self.transform = T.Compose(transforms)

        if samples is not None:
            self.samples = samples
            return

        self.samples = []
        skipped = 0
        real_captions = 0
        fallback_captions = 0

        if not os.path.exists(data_dir):
            return

        for item in os.listdir(data_dir):
            item_path = os.path.join(data_dir, item)

            if os.path.isdir(item_path):
                files_to_check = [(f, os.path.join(item_path, f), item) for f in os.listdir(item_path)]
            else:
                files_to_check = [(item, item_path, os.path.splitext(item)[0])]

            for fname, img_path, default_caption in files_to_check:
                if not fname.lower().endswith(('.png', '.jpg', '.jpeg')):
                    continue

                try:
                    img = Image.open(img_path)
                    img.verify()
                except Exception:
                    skipped += 1
                    continue

                base_name = os.path.splitext(fname)[0]
                parent_dir = os.path.dirname(img_path)
                txt_path = os.path.join(parent_dir, base_name + '.txt')

                if os.path.exists(txt_path):
                    with open(txt_path, 'r', encoding='utf-8') as f:
                        caption = f.read().strip()
                    real_captions += 1
                else:
                    caption = default_caption
                    fallback_captions += 1
                    print(f"[ImageLoader] No caption file for {img_path}, using fallback: '{caption}'")

                self.samples.append((img_path, caption))

        if skipped > 0:
            print(f"[ImageLoader] Skipped {skipped} corrupted/unreadable image files.")
        print(f"[ImageLoader] Loaded {len(self.samples)} images ({real_captions} with captions, {fallback_captions} using fallback names).")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, caption = self.samples[idx]
        image = Image.open(img_path)
        if image.mode != "RGB":
            image = image.convert("RGB")
        img_tensor = self.transform(image)
        
        if self.tokenizer is not None:
            tokens = self.tokenizer.encode(caption)
            if len(tokens) > self.max_seq_len:
                tokens = tokens[:self.max_seq_len]
            else:
                tokens = tokens + [0] * (self.max_seq_len - len(tokens))
            return img_tensor, torch.tensor(tokens, dtype=torch.long)
            
        return img_tensor, caption
